import numpy as np
import cv2
import sys

print ('reading',sys.argv[1])
IM1 = cv2.imread(sys.argv[1])
print (IM1.shape)
print ('reading',sys.argv[2])
IM2 = cv2.imread(sys.argv[2])
print (IM2.shape)

if IM1.all() == IM2.all():
    print ('Two images are the same')
else:
    print ('Two images are different')