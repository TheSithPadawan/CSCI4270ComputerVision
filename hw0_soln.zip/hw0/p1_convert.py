import cv2         
import numpy as np
import os
import random
import sys

# Input: A three-element tuple representing BGR value
# Output: A formated string (R,G,B) 
def formatAdjust(t1):
    s = '({},{},{})'.format(t1[2], t1[1], t1[0])
    return s

# Input: x,y index to numpy array
#        img: original image; new_img: image after grayscale
# Output: I/O
def display_intensity(x, y,img,new_img):
    t1 = tuple(list(img[x,y]))
    s = formatAdjust(t1)
    print ('(%d,%d): ' %(x, y), end = '') 
    print (s,'->',new_img[x,y])

'''
Input: Numpy array; will broadcast the weight combination to get a new array
Ouput: the new image
'''
def toGray(img): 
    w = np.array([0.114, 0.587, 0.299])
    new = img * w # broadcast 
    new = np.sum(new, axis = 2)
    new = new.astype(np.uint8) # cast back to unsigned byte
    return new

# the function that calls everything
def p1(name):
    img = cv2.imread(name)
    print ('Shape before:', img.shape)
    # gray scale image would just be changing taking the first two dimensions
    new_img = toGray(img)
    outFile = name.split('.')[0]+'_g.jpg'
    cv2.imwrite(outFile, new_img)
    print ('Shape after:',new_img.shape)
    #display intensity at different locations
    M = img.shape[0]
    N = img.shape[1]
    display_intensity(M//4,N//4,img,new_img)
    display_intensity(M//4,3*N//4,img,new_img)
    display_intensity(3*M//4,N//4,img,new_img)
    display_intensity(3*M//4,3*N//4,img,new_img)
    print ('Out file:',outFile)

if __name__ == '__main__':
    fileName = sys.argv[1]
    p1(fileName)
