import cv2         
import numpy as np
from matplotlib import pyplot as plt 
import matplotlib   
import os
import random
import sys
import itertools

# generate a 2D matrix of shading multiplier
# by generating two basic one: row dist and col dist first
# then manipulate these two to get others
def generateMultiplier(x, y, d): #x is row, y is col
    row_dist = np.tile(np.arange(y),(x,1))
    k = np.tile(np.arange(x),(y,1))
    col_dist = np.transpose(k) # column dist is just the transpose of row dist
    if d == 'left':
        dist_arr = row_dist/np.max(row_dist)
    elif d == 'topleft':
        dist_arr = np.sqrt(np.square(row_dist) + np.square(col_dist))
        dist_arr = dist_arr/ np.max(dist_arr)
    elif d == 'top':
        dist_arr = col_dist/np.max(col_dist)
    elif d == 'topright':
        dist_arr = np.sqrt(np.square(row_dist[:,::-1]) + np.square(col_dist))
        dist_arr = dist_arr/ np.max(dist_arr)        
    elif d == 'right':
        dist_arr = row_dist[:,::-1]/np.max(row_dist) # just reversed column
    elif d == 'bottomright':
        dist_arr = np.sqrt(np.square(row_dist[:,::-1]) + np.square(col_dist[::-1,:]))
        dist_arr = dist_arr/ np.max(dist_arr)                            
    elif d == 'bottom': # just reversed row
        dist_arr = col_dist[::-1,:]/np.max(col_dist)
    elif d == 'bottomleft':
        dist_arr = np.sqrt(np.square(row_dist) + np.square(col_dist[::-1,:]))
        dist_arr = dist_arr/ np.max(dist_arr)      
    return dist_arr

# multiply each channel by multipliers
def shade(img, dist_arr):
    new_img = np.copy(img)
    new_img[:,:,0] = img[:,:,0] * dist_arr # b channel
    new_img[:,:,1] = img[:,:,1] * dist_arr # g channel
    new_img[:,:,2] = img[:,:,2] * dist_arr # r channel
    return new_img
    
# the function that calls everything and outputs the final result
def p2(in_name, out_name, d):
    img = cv2.imread(in_name)    
    mul = generateMultiplier(img.shape[0],img.shape[1],d)
    new_img = shade(img, mul)
    params = itertools.product([0,img.shape[0]//2, img.shape[0]-1],[0,img.shape[1]//2, img.shape[1]-1])
    final = np.concatenate((img,new_img), axis = 1)    
    cv2.imwrite(out_name, final)        
    
    for (c1, c2) in params:
        print('(%d,%d) %.4f' % (c1,c2,mul[c1,c2]))

if __name__ == '__main__':
    p2(sys.argv[1],sys.argv[2],sys.argv[3])
