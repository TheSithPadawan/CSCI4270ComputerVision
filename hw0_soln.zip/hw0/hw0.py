import cv2         
import numpy as np
from matplotlib import pyplot as plt 
import matplotlib   
import os
import random
import sys
import itertools

# debugging only
def display_img_opencv_full_size(img_name, img):
    """
    We can display images directly through OpenCV.  You will notice
    that this generates a huge window.
    """
    cv2.imshow(img_name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    return

def display_intensity(x, y,img,new_img):
    t1 = tuple(list(img[x,y]))
    print ('(%d, %d):' %(x, y), t1,'->',new_img[x,y])

def toGray(img): #过于尴尬...
    w = np.array([0.114, 0.587, 0.299])
    new = img * w # broadcast 
    new = np.sum(new, axis = 2)
    new = np.round(new) # round up.. 
    new = new.astype(np.uint8) # cast back to unsigned byte
    return new
        
def p1(name):
    img = cv2.imread(name)
    print ('Shape before:', img.shape)
    # gray scale image would just be changing taking the first two dimensions
    new_img = toGray(img)
    # save the file --> need to uncomment
    outFile = name.split('.')[0]+'_g.jpg'
    cv2.imwrite(outFile, new_img)
    print ('Shape after:',new_img.shape)
    #display intensity
    M = img.shape[0]
    N = img.shape[1]
    display_intensity(M//4,N//4,img,new_img)
    display_intensity(M//4,3*N//4,img,new_img)
    display_intensity(3*M//4,N//4,img,new_img)
    display_intensity(3*M//4,3*N//4,img,new_img)
    print ('Out file:',outFile)
    '''
    need to comment out the testing part later
    '''
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   
    print ('stats using cv2 cvtColor')
    display_intensity(M//4,N//4,img,img_gray)
    display_intensity(M//4,3*N//4,img,img_gray)
    display_intensity(3*M//4,N//4,img,img_gray)
    display_intensity(3*M//4,3*N//4,img,img_gray)    
    
# generate a 2D matrix of shading multiplier
def generateMultiplier(x, y, d): #x is row, y is col
    row_dist = np.tile(np.arange(y),(x,1))
    k = np.tile(np.arange(x),(y,1))
    col_dist = np.transpose(k)
    if d == 'left':
        dist_arr = row_dist/np.max(row_dist)
    elif d == 'topleft':
        dist_arr = np.sqrt(np.square(row_dist) + np.square(col_dist))
        dist_arr = dist_arr/ np.max(dist_arr)
    elif d == 'top':
        dist_arr = col_dist/np.max(col_dist)
    elif d == 'topright':
        dist_arr = np.sqrt(np.square(row_dist[:,::-1]) + np.square(col_dist))
        dist_arr = dist_arr/ np.max(dist_arr)        
    elif d == 'right':
        dist_arr = row_dist[:,::-1]/np.max(row_dist) # reversed column
    elif d == 'bottomright':
        dist_arr = np.sqrt(np.square(row_dist[:,::-1]) + np.square(col_dist[::-1,:]))
        dist_arr = dist_arr/ np.max(dist_arr)                            
    elif d == 'bottom': # reversed row
        dist_arr = col_dist[::-1,:]/np.max(col_dist)
    elif d == 'bottomleft':
        dist_arr = np.sqrt(np.square(row_dist) + np.square(col_dist[::-1,:]))
        dist_arr = dist_arr/ np.max(dist_arr)      
    return dist_arr

def shade(img, dist_arr):
    new_img = np.copy(img)
    new_img[:,:,0] = img[:,:,0] * dist_arr # b channel
    new_img[:,:,1] = img[:,:,1] * dist_arr # g channel
    new_img[:,:,2] = img[:,:,2] * dist_arr # r channel
    return new_img
    

def p2(in_name, out_name, d):
    img = cv2.imread(in_name)    
    mul = generateMultiplier(img.shape[0],img.shape[1],d)
    new_img = shade(img, mul)
    # display_img_opencv_full_size(out_name, new_img)
    params = itertools.product([0,img.shape[0]//2, img.shape[0]-1],[0,img.shape[1]//2, img.shape[1]-1])
    final = np.concatenate((img,new_img), axis = 1)    
    cv2.imwrite(out_name, final)        
    display_img_opencv_full_size(out_name, final)
    
    for (c1, c2) in params:
        print('(%d,%d) %.4f' % (c1,c2,mul[c1,c2]))

def extractRGBVec(img):
    mean_b = np.average(img[:,:,0])
    mean_g = np.average(img[:,:,1])
    mean_r = np.average(img[:,:,2])
    return np.round(np.array([mean_r,mean_g,mean_b]),1)

def centerCrop(img):
    print (type(img))
    h = img.shape[0]
    w = img.shape[1]
    print (h,w)
    if h < w: # crop the width
        start = (w-h)//2
        end = h + (w-h)//2
        new_img = img[:,start:end,:]
    elif h > w: # crop the height
        new_img = np.zeros((h,h))
        start = (h - w)//2
        end = w + (h - w)//2
        new_img = img[start:end,:,:]
    else:
        print('no cropping necessary')
        new_img = img
    return new_img

def buildChecker(img1, img2, M, N, s):
    # cropping two images
    img1 = centerCrop(img1)
    img2 = centerCrop(img2)
    print ('Shape after center crop',img1.shape,img2.shape)    
    # resizing to s by s pixel
    img1 = cv2.resize(img1, (s,s))          
    img2 = cv2.resize(img2, (s,s))
    final = np.zeros((M*s, N*s))
    row1 = np.concatenate((img1,img2),axis = 1)
    row2 = np.concatenate((img2,img1),axis = 1)
    flag = 0
    for i in range(N-2):
        if flag == 0:
            row1 = np.concatenate((row1, img1),axis = 1)
            row2 = np.concatenate((row2, img2),axis = 1)            
            flag = 1
        else:
            row1 = np.concatenate((row1, img2), axis = 1)
            row2 = np.concatenate((row2, img1),axis = 1)            
            flag = 0

    twoRows = np.concatenate((row1,row2),axis = 0)
    final = np.tile(twoRows, (M//2,1,1))
    return final

if __name__ == '__main__':
    if sys.argv[1] =='p1_convert':
        print ('executing problem 1 code')
        fileName = sys.argv[2]
        p1(fileName)
    elif sys.argv[1] == 'p2_shade':
        p2(sys.argv[2],sys.argv[3],sys.argv[4])
    elif sys.argv[1] == 'p3_checkerboard':
        # preprocessing craps...
        imgs = [f for f in os.listdir(sys.argv[2]) if f.endswith('.jpg') if f.split('.')[0].isalpha()]
        # create oridinary checkerboard
        H = int(sys.argv[4])
        W = int(sys.argv[5])
        S = int(sys.argv[6])
        out = sys.argv[3]
        IM1 = np.zeros((H*S, W*S, 3))
        IM1.fill(255)
        IM2 = np.copy(IM1)
        IM2.fill(0)
        
        if len(imgs) == 0:
            print ('No images. Creating an ordinary checkerboard.')
            disp = buildChecker(IM1, IM2, H,W,S)
            cv2.imwrite(out,disp)             
        elif len(imgs) == 1:
            print ('One image:',imgs[0],'It will form the white square.')
            # create one image to be white
            IM1 = cv2.imread(sys.argv[2] + '/' + imgs[0]) 
            disp = buildChecker(IM1, IM2, H,W,S)
            cv2.imwrite(out,disp)                    
        elif len(imgs) == 2:
            print ('Exactly two images:', imgs[0], 'and', imgs[1],'Creating a checkerboard for them.')
            IM1 = cv2.imread(sys.argv[2] + '/' + imgs[0])
            IM2 = cv2.imread(sys.argv[2] + '/' + imgs[1])
            disp = buildChecker(IM1, IM2, H,W,S)
            cv2.imwrite(out,disp)            
        else:
            dct = {}
            for pic in imgs:
                img = cv2.imread(pic)
                vec = extractRGBVec(img) 
                print(pic,vec) # need to print in tuple form
                dct[pic] = vec
            I1 = ''
            I2 = ''
            longestDist = 0
            
            for k1 in dct.keys():
                for k2 in dct.keys():
                    if np.linalg.norm(dct[k1] - dct[k2])>longestDist:
                        I1 = k1
                        I2 = k2
                        longestDist = np.linalg.norm(dct[k1] - dct[k2])
            print ('Checkerboard from',I1,'and',I2,'Distance between them is %.1f' %longestDist)
            IM1 = cv2.imread(sys.argv[2] + '/'+I1)
            IM2 = cv2.imread(sys.argv[2] + '/'+I2)
            disp = buildChecker(IM1, IM2, H,W,S)
            cv2.imwrite(out,disp)
            
                