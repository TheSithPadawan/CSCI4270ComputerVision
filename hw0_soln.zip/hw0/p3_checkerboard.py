import cv2         
import numpy as np
import os
import random
import sys

# Input: A three-element tuple representing RGB value
# Output: A formated string (R,G,B) 
def formatAdjust(t1):
    s = '({:.1f}, {:.1f}, {:.1f})'.format(t1[0], t1[1], t1[2])
    return s

# extract mean r g b values
def extractRGBVec(img):
    mean_b = np.average(img[:,:,0])
    mean_g = np.average(img[:,:,1])
    mean_r = np.average(img[:,:,2])
    return np.array([mean_r,mean_g,mean_b])

# croping image
def centerCrop(img):
    h = img.shape[0]
    w = img.shape[1]
    if h < w: # crop the width
        start = (w-h)//2
        end = h + (w-h)//2
        new_img = img[:,start:end,:]
        print ('Image cropped at ({},{}) and ({},{})'.format(0,start,h-1,end-1))
    elif h > w: # crop the height
        new_img = np.zeros((h,h))
        start = (h - w)//2
        end = w + (h - w)//2
        new_img = img[start:end,:,:]
        print ('Image cropped at ({},{}) and ({},{})'.format(start,0,w+start-1,w-1))        
    else:
        print('Image does not require cropping')
        new_img = img
    return new_img

# check if resize is needed, if so, resize
def resize(img, s):
    if img.shape[0] == s and img.shape[1] == s:
        print ('No resizing needed')
    else:
        img1 = cv2.resize(img, (s,s)) 
        print ('Resized from ({}, {}, {}) to ({}, {}, {})'.format(img.shape[0],img.shape[1],img.shape[2],\
                                                              img1.shape[0],img1.shape[1],img1.shape[2],))
        img = img1
    return img

# build the checker board
def buildChecker(img1, img2, M, N, s):
    # cropping and resize if needed
    img1 = centerCrop(img1)
    img1 = resize(img1, s)    
    img2 = centerCrop(img2)    
    img2 = resize(img2, s)
    final = np.zeros((M*s, N*s))
    # build the first two 
    row1 = np.concatenate((img1,img2),axis = 1)
    row2 = np.concatenate((img2,img1),axis = 1)
    flag = 0
    # repeat the pattern of the first two columns
    for i in range(N-2):
        if flag == 0:
            row1 = np.concatenate((row1, img1),axis = 1)
            row2 = np.concatenate((row2, img2),axis = 1)            
            flag = 1
        else:
            row1 = np.concatenate((row1, img2), axis = 1)
            row2 = np.concatenate((row2, img1),axis = 1)            
            flag = 0
    # repeat the pattern for the first two rows
    twoRows = np.concatenate((row1,row2),axis = 0)
    final = np.tile(twoRows, (M//2,1,1))
    return final

if __name__ == '__main__':
    imgs = [f for f in os.listdir(sys.argv[1]) if f.lower().endswith('.jpg')]
    imgs.sort()
    H = int(sys.argv[3])
    W = int(sys.argv[4])
    S = int(sys.argv[5])
    out = sys.argv[2]
    
    # create two basic pattern, black and white
    IM1 = np.zeros((S, S, 3))
    IM1.fill(255)
    IM2 = np.copy(IM1)
    IM2.fill(0)
    
    # do different things according to different number of images found
    if len(imgs) == 0:
        print ('No images. Creating an ordinary checkerboard.')
        disp = buildChecker(IM1, IM2, H,W,S)
        cv2.imwrite(out,disp)             
    elif len(imgs) == 1:
        print ('One image: %s.' % imgs[0],'It will form the white square.')
        # create one image to be white
        IM1 = cv2.imread(sys.argv[1] + '/' + imgs[0]) 
        disp = buildChecker(IM1, IM2, H,W,S)
        cv2.imwrite(out,disp)                    
    elif len(imgs) == 2:
        print ('Exactly two images: %s and %s.' % (imgs[0], imgs[1]),'Creating checkerboard from these.')
        IM1 = cv2.imread(sys.argv[1] + '/' + imgs[0])
        IM2 = cv2.imread(sys.argv[1] + '/' + imgs[1])
        disp = buildChecker(IM1, IM2, H,W,S)
        cv2.imwrite(out,disp)            
    else:
        # extract mean RGB
        dct = {}
        for pic in imgs:
            img = cv2.imread(sys.argv[1] + '/'+ pic)
            vec = extractRGBVec(img) 
            print(pic,formatAdjust(vec))
            dct[pic] = vec
        I1 = ''
        I2 = ''
        longestDist = 0

# calculate longest distance using 2 norm of the vector
        for k1 in dct.keys():
            for k2 in dct.keys():
                if np.linalg.norm(dct[k1] - dct[k2],ord = 2)>longestDist:
                    I1 = k1
                    I2 = k2
                    longestDist = np.linalg.norm(dct[k1] - dct[k2])

        # the one with higher magnitude will be printed first
        if np.linalg.norm(dct[I1],ord = 1) > np.linalg.norm(dct[I2],ord = 1):
            IM1 = cv2.imread(sys.argv[1] + '/'+I1)
            IM2 = cv2.imread(sys.argv[1] + '/'+I2)
            print ('Checkerboard from %s and %s.' %(I1, I2),'Distance between them is %.1f' % longestDist)                
        else:
            IM1 = cv2.imread(sys.argv[1] + '/'+I2)
            IM2 = cv2.imread(sys.argv[1] + '/'+I1)                
            print ('Checkerboard from %s and %s.' %(I2, I1),'Distance between them is %.1f' % longestDist)
# build checkerboard
        disp = buildChecker(IM1, IM2, H,W,S)
        cv2.imwrite(out,disp)    
