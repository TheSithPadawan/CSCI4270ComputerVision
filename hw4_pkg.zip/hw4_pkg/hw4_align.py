import numpy as np
import cv2
import os
from matplotlib import pyplot as plt
import sys

# compute SIFT features
# Fundamental and Homography Estimation
# returns error indicator: -1, -1 or Fundamental matrix and Homography matrix
def kpMatch(im1, im2, outImg):
    im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY)
    im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY)
    sift = cv2.xfeatures2d.SIFT_create()
    kp1, des1 = sift.detectAndCompute(im1,None)
    kp2, des2 = sift.detectAndCompute(im2,None)
    
    # using brute force matching b/c opencv FLANN is broken...
    bf = cv2.BFMatcher()
    # for each kp in des1, get 2 best matches in des2
    matches = bf.knnMatch(des1, des2, k = 2)
    # apply ratio test where a good match has ratio < 0.8
    good = []
    pts1 = []
    pts2 = []
    for m,n in matches:
        if m.distance < 0.8*n.distance:
            good.append([m])
            pts2.append(kp2[m.trainIdx].pt)
            pts1.append(kp1[m.queryIdx].pt)
    pts1 = np.array(pts1)
    pts2 = np.array(pts2)
    good = np.array(good)
    print ('Number of matches found %d' % good.shape[0])
    out = cv2.drawMatchesKnn(im1, kp1, im2, kp2, good, None, flags = 2)
    cv2.imwrite(outImg+'_m0.jpg',out)

    # Fundamental Matrix Estimation
    FM, Mask = getFM(pts1, pts2)
    fm_matches = good[Mask.ravel() == 1]
    avgErr = errorMetric(pts1, pts2, FM)
    print ('Number of inliers after F Estimate %d' % (fm_matches.shape[0]))
    print ('Decision after F estimate:')
    img4 = cv2.drawMatchesKnn(im1, kp1, im2, kp2, fm_matches, None, flags = 2)
    cv2.imwrite(outImg+'_m1.jpg',img4)
    # threshold on 20%...based on observations and experiences..
    if (fm_matches.shape[0]>0.2*good.shape[0]):
        print ('Recognized as same scene')
    else:
        print ('Too few inliers after F estimate -- Different scene')
        return 0,0,-1

    # Homography Estimation
    H, Stat = cv2.findHomography(pts1, pts2, cv2.RANSAC,ransacReprojThreshold=1.0,confidence = 0.99)
    h_matches = good[Stat.ravel()==1]
    print ('Number of inliers after H Estimate %d' % (h_matches.shape[0]))
    img5 = cv2.drawMatchesKnn(im1, kp1, im2, kp2, h_matches, None, flags = 2)
    cv2.imwrite(outImg+'_m2.jpg',img5)
    if (h_matches.shape[0]> good.shape[0]*0.3+8):
        print ('Decision after H estimate:')
        print (outImg,'Able to align')
    else:
        print (outImg,'Unable to align')
        return 0,0,-1
    return FM, H, 1

# get fundamental matrix    
def getFM(pts1, pts2):
    FM, Mask = cv2.findFundamentalMat(pts1, pts2, cv2.FM_RANSAC, param1 = 1.0, param2 = 0.99)
    return FM, Mask

# compute the residual after homography
def errorMetric(pts1, pts2, FM):
    lines2 = cv2.computeCorrespondEpilines(pts1, 1, FM) # epilines on Image 2
    assert(lines2.shape[0] == pts1.shape[0])
    distances = []
    for i in range(lines2.shape[0]):
        a = lines2[i,0,0]
        b = lines2[i,0,1]
        c = lines2[i,0,2]
        dist = abs(a*pts2[i,0] + b*pts2[i,1] +c)/np.sqrt(a**2+b**2)
        distances.append(dist)    
    print ("avg error per match",np.mean(np.array(distances)))
    return np.mean(np.array(distances))

# remap the four corners ABCD to new system
# A,B,C,D represented in homogeneous form
# return A,B,C,D in pixel coordinates
def remap(H,A,B,C,D):
    A_ = np.dot(H, A)
    B_ = np.dot(H, B)
    C_ = np.dot(H, C)
    D_ = np.dot(H, D)
    return A_/A_[-1], B_/B_[-1], C_/C_[-1], D_/D_[-1]

# calculate translation offset based on four corners
def getOffset(H, IM1, IM2):
     start,end,lowerL,upperR = remap(H,np.array([0,0,1]), np.array([IM1.shape[1], IM1.shape[0], 1]), np.array([0,IM1.shape[0],1]),np.array([IM1.shape[1],0,1]))
     Min_x = min([start[0], end[0], lowerL[0], upperR[0]])
     Min_y = min([start[1], end[1], lowerL[1], upperR[1]])
     offsetx = 0
     offsety = 0
     if Min_x < 0:
         offsetx = abs(Min_x)
     if Min_y < 0:
         offsety = abs(Min_y)
     return offsetx,offsety

 # pick the transformation that has less distortion
 # evaluate distortion based on the norm of h31 and h32
def testOffset(H, IM1, IM2, outImgName):
    norm1 = np.sqrt(H[-1,0]**2 + H[-1,1]**2)
    norm2 = np.sqrt(np.linalg.inv(H)[-1,0]**2 + np.linalg.inv(H)[-1,1]**2)
    print ('norm1:',norm1,'norm2:',norm2)
    if norm1 < norm2:
        print ('warping direction chosen: IM1->IM2')
        ox1,oy1 = getOffset(H, IM1, IM2)
        mat = np.array([[1,0,ox1],[0,1,oy1],[0,0,1]])
        composite = np.dot(mat, H)
        warpAndstitch(composite, ox1,oy1, im1,im2,outImgName)
    else:
        print ('warping direction chosen: IM2->IM1')
        ox2, oy2 = getOffset(np.linalg.inv(H),IM1,IM2 )
        mat = np.array([[1,0,ox2],[0,1,oy2],[0,0,1]])
        composite = np.dot(mat, np.linalg.inv(H))
        warpAndstitch(composite, ox2,oy2, im2,im1,outImgName)

# stitch image together given translation vector
def warpAndstitch(composite, offsetx, offsety, IM1, IM2, outImgName):
    # calculate new coordinates for IM1
    start,end,lowerL,upperR = remap(composite,np.array([0,0,1]), np.array([IM1.shape[1], IM1.shape[0], 1]), np.array([0,IM1.shape[0],1]),np.array([IM1.shape[1],0,1]))
    # calculate new coordinates for IM2
    IM2_start = (offsetx, offsety)
    IM2_lowerL = (offsetx, offsety+IM2.shape[0])
    IM2_upperR = (offsetx+IM2.shape[1],offsety)
    IM2_end = (offsetx + IM2.shape[1], offsety + IM2.shape[0])
    # calculate new image size
    new_size_row = max([start[1],end[1],lowerL[1],upperR[1],IM2_start[1],IM2_end[1],IM2_lowerL[1],IM2_upperR[1]])
    new_size_col = max([start[0], end[0], lowerL[0], upperR[0],IM2_start[0],IM2_end[0],IM2_lowerL[0],IM2_upperR[0]])
    print ('New Image Size (Row, Col)', int(new_size_row)+1, int(new_size_col)+1)
    
    # using bi-linear interpolation
    result = cv2.warpPerspective(IM1, composite, (int(new_size_col),int(new_size_row)), flags = cv2.INTER_LINEAR)
    result2 = np.zeros(result.shape,dtype = result.dtype)
    result2[int(offsety):IM2.shape[0]+int(offsety), int(offsetx):IM2.shape[1]+int(offsetx)] = IM2

    # create mask for each image for compositing
    im1_canvas = np.zeros(result.shape,dtype = np.float32)
    im1_canvas[np.where(result>0)]=1
    im2_canvas = np.zeros(result.shape,dtype = np.float32)
    im2_canvas[int(offsety):IM2.shape[0]+int(offsety), int(offsetx):IM2.shape[1]+int(offsetx)] = 1

    # using multiplication to combine the weights on each mask
    composite = im1_canvas+im2_canvas
    mask1 = np.copy(im1_canvas)
    mask1[np.where(composite==2)]=0.15# weight given to overlap region = .15 VS .85
    mask2 = np.copy(im2_canvas)
    mask2[np.where(composite==2)]=0.85
    im1_partial = mask1*result
    im2_partial = mask2*result2
    final = im1_partial + im2_partial
    
    # apply Gaussian Bluring with a small kernel and sigma for better smoothing effect
    final = cv2.GaussianBlur(final,(3,3),2)
    cv2.imwrite(outImgName,final)
    
if __name__ == "__main__":
    
    im_list = [f for f in os.listdir(sys.argv[1]) if f.lower().endswith('.jpg')]
    print (im_list)

    # Work on each pair 
    for i in range(len(im_list)):
        for j in range(i+1, len(im_list)):
            f1 = im_list[i].split('.')[0]
            f2 = im_list[j].split('.')[0]
            im1 = cv2.imread(os.path.join(sys.argv[1], im_list[i]))
            im2 = cv2.imread(os.path.join(sys.argv[1], im_list[j]))
            print ("Working on images %s and %s" % (f1, f2))
            outName = f1 + '_' + f2
            FM,H,flag = kpMatch(im1, im2, outName)
            if flag == 1:
                print ('Stitching images...')
                testOffset(H, im1, im2,outName+'.jpg')
            elif flag == -1:
                print ('Continuing...')
            print ()
