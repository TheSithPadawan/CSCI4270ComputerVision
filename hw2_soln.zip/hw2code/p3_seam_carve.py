import cv2
import numpy as np
import sys
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt

def calcCost(img):
    # first convert to grayscale before calculating derivatives
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    rows = img.shape[0]
    cols = img.shape[1]
    # compute Sobel derivative at each pixel location
    im_dx = cv2.Sobel(gray, cv2.CV_32F, 1, 0)
    im_dy = cv2.Sobel(gray, cv2.CV_32F, 0, 1)
    
    # calculate cost matrix
    cost = np.absolute(im_dx) + np.absolute(im_dy)
    
    # weight matrix as your DP table
    # adjust the 0th cost and last cost to be a large number
    w = np.zeros((rows, cols))
    w[0] = cost[0]
    w[0,0] = sys.maxsize
    w[0,-1] = sys.maxsize
    # doing dp over here
    for i in range(1, rows):
        w[i] = cost[i] + localMin(w[i-1])
        w[i,0] = sys.maxsize
        w[i,-1] = sys.maxsize

    # average energy value
    w = w/rows
    return w

    
# backtrace to the actual seam
# ind: min index in the last row; w: the DP table
def vseam(ind, w):
    min_seam = []
    rows = w.shape[0]
    cols = w.shape[1]
    min_seam.append(ind) # ind is the column index with min total energy
    for i in range(rows-2, -1, -1):
        # ind2: choose a direction to go: upperleft; up; upperright
        ind2 = np.argmin(np.array([w[i,ind-1],w[i,ind],w[i,ind+1]]))
        if ind2 == 0:
            min_seam.append(ind - 1)
            ind -= 1
        elif ind2 == 1:
            min_seam.append(ind)
        elif ind2 == 2:
            min_seam.append(ind+1) 
            ind += 1
    arr = np.array(min_seam[::-1])# to sort from row 1 to row M
    return arr

# using array concatenation to filter out undesirable points
def test(seam, CIM):
    storage = []
    rows = CIM.shape[0]
    for i in range(rows):
        current_row = CIM[i]
        newrow = np.vstack([current_row[:seam[i]], current_row[seam[i]+1:]])
        storage.append(newrow)
    newIM = np.array(storage)
    return newIM

# finding the local mins in DP calculation by shifting left/right
def localMin(w):
    L = w[:-2]
    R = w[2:]
    C = w[1:-1]
    V = [L,C,R]
    min_vals = np.zeros_like(w)
    min_vals[1:-1] = np.asarray(V).min(0)[:] # middle
    min_vals[0] = np.amin(np.asarray([w[0],w[1]])) # left border
    min_vals[-1] = np.amin(np.asarray([w[-1],w[-2]])) # right border
    return min_vals

# main:

if __name__ == "__main__":
    # read the image
    img = cv2.imread(sys.argv[1])
    if img.shape[0] > img.shape[1]: # if horizontal, flip the image
        DIR = 'h'
        #img = np.rot90(img,1)
        img = np.transpose(img, (1,0,2))
        
    else:
        DIR = 'v'
    
    r = img.shape[0]
    c = img.shape[1]
    xaxis = []
    yaxis = []
    count = 0
    while True:
        if (img.shape[0] == img.shape[1]): # succesfully reshape into a square
            break
        # get the DP table
        w = calcCost(img)
        idx = np.argmin(w[-1,:])
        min_seam = vseam(idx,w) # coordinates of the seam
         # remove Seam and continue    
        img = test(min_seam, img)
        if count == 0 or count==1 or count == max([r,c]) - min([r,c])-1:
            print ()
            print ('Points on seam %d:' % count)
            if DIR == 'v':
                print ('vertical')
                print ("{}, {}".format(0, min_seam[0]))
                print ("{}, {}".format(r//2, min_seam[min_seam.shape[0]//2]))
                print ("{}, {}".format(r-1, min_seam[-1]))
                print ('Energy of seam %d: %.2f' % (count, w[-1,idx]))
            else:
                print ('horizontal')
                print ("{}, {}".format(min_seam[0],0))
                print ("{}, {}".format(min_seam[r//2],r//2))
                print ("{}, {}".format(min_seam[-1], r-1))
                print ('Energy of seam %d: %.2f' % (count, w[-1,idx]))
       
        # add seam and energy to a list for plotting
        xaxis.append(count)
        yaxis.append(w[-1, idx])
        count += 1

    # output the image
    if DIR == 'v':
        cv2.imwrite(sys.argv[2], img)
    elif DIR == 'h':
        img = np.transpose(img, (1,0,2))
        cv2.imwrite(sys.argv[2],img)

    # plot energy graph
    plt.plot(xaxis,yaxis)
    plt.xlabel('Seam number')
    plt.ylabel('Average pixel energy')
    plt.savefig(sys.argv[3])
