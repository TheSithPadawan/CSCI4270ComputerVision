import cv2
import numpy as np
import sys


img = cv2.imread(sys.argv[1],cv2.IMREAD_GRAYSCALE)
# compute Sobel derivative at each pixel location
im_dx = cv2.Sobel(img, cv2.CV_64F, 1, 0)
im_dy = cv2.Sobel(img, cv2.CV_64F, 0, 1)

output = np.abs(im_dx) + np.abs(im_dy)
output = output.astype(np.uint8)
cv2.imwrite('testout.jpg', output)
