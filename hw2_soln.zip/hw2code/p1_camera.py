import cv2
import numpy as np
import sys

#Rotation matrix of x axis
def Rx (x):
    row1 = np.array([1,0,0])
    row2 = np.array([0,np.cos(x),-np.sin(x)])
    row3 = np.array([0,np.sin(x), np.cos(x)])
    return np.vstack([row1,row2,row3])

# Rotation matrix of y axis
def Ry (x):
    row1 = np.array([np.cos(x),0,np.sin(x)])
    row2 = np.array([0,1,0])
    row3 = np.array([-np.sin(x),0,np.cos(x)])
    return np.vstack([row1,row2,row3])

# Rotation matrix of z axis
def Rz (x):
    row1 = np.array([np.cos(x),-np.sin(x),0])
    row2 = np.array([np.sin(x),np.cos(x),0])
    row3 = np.array([0,0,1])
    return np.vstack([row1,row2,row3])

# Compose three rotation matrices
def Rotation(r):
    rx = Rx(r[0])
    ry = Ry(r[1])
    rz = Rz(r[2])
    tmp = np.dot(rx,ry)
    return np.dot(tmp,rz)

# Rotation + translate
def RT(r, t):
    new = np.zeros((r.shape[0],r.shape[1]+1))
    new[:,0:-1] = r
    new[:,-1] = t
    return new

# K Matrix
def K(p):
    f = p[0]
    d = p[1] * 0.001 # convert micron to mm
    ic = p[2]
    jc = p[3]
    s = f/d
    row1 = np.array([s,0,ic])
    row2 = np.array([0,s,jc])
    row3 = np.array([0,0,1])
    return np.vstack([row1,row2,row3])

# Form a camera matrix by composing K and three rotation matrices
def M(r, t, p):
    RMatrix = Rotation(r)
    tprime = -np.dot(np.transpose(RMatrix),t)
    rt = RT(np.transpose(RMatrix), tprime)
    KMatrix = K(p)
    return np.dot(KMatrix, rt)

# Determine if a point is inside or outside the image plane
# By size comparison
def decide(loc):
    row = loc[1]
    col = loc[0]
    if (0<=row<=4000 and 0<=col<=6000):
        print ('%.1f %.1f inside' % (row,col))
    else:
        print ('%.1f %.1f outside' % (row, col))

# Determine if a point is above/below a plane by
# Taking the dot producs of the plane normal and position vector
def visible(p0,r,t):
    rmat = Rotation(r)
    p = rmat.dot(np.array([0,0,0])) + t # camera center
    axis = rmat.dot(np.array([0,0,1]))
    normalized_axis = axis/np.linalg.norm(axis)# normalized optical axis
    ret = np.inner(normalized_axis ,p0-p)
    if (ret > 0): # above --> visible
        return True
    else: # below --> hidden
        return False

# pretty print a matrix to IO
def prettyprint(arr):
    for i in range(arr.shape[0]):
        # camera matrix is guaranteed to be 3 by 4
        outstr = "{:.2f}, {:.2f}, {:.2f}, {:.2f}".format(arr[i][0],arr[i][1],arr[i][2],arr[i][3])
        print (outstr)

# projects a point to a plane
def project(points,r,t):
    augment = RT(points,np.array([1]*points.shape[0]))
    points_t = np.transpose(augment)
    pixle_loc = np.dot(camera_matrix,points_t)
    pixle_loc[0] = pixle_loc[0]/pixle_loc[-1]
    pixle_loc[1] = pixle_loc[1]/pixle_loc[-1]
    img_loc = pixle_loc[0:2,:]
    # printing
    vs = [] # store the indices of visible ones
    hd = [] # store the indices of the hidden ones
    print ('Projections:')
    for i in range(img_loc.shape[1]):
        outstr = '{}: {:.1f} {:.1f} {:.1f}'.format(i,points[i][0], points[i][1], points[i][2])
        print (outstr, '=> ',end = '')
        decide(img_loc[:,i])
        ret = visible(points[i], r, t)
        if ret:
            vs.append(i)
        else:
            hd.append(i)
    print ('visible:',*vs)
    print ('hidden:',*hd)
        
#main
if __name__ == "__main__":
    lines = []
    with open (sys.argv[1]) as f:
        for line in f:
            line = line.strip().split()
            lines.append(line)
    r = np.array(lines[0],dtype = np.float)
    # convert degree to radian to use in sine and cosine calculation
    r = np.deg2rad(r)
    t = np.array(lines[1], dtype = np.float)
    params = np.array(lines[2], dtype = np.float)
    camera_matrix = M(r,t,params)
    print ('Matrix M:')
    prettyprint(camera_matrix)
    
    #read in the points and in affine coordinates
    points = np.loadtxt(sys.argv[2])
    # project the points onto image
    project(points,r,t)
