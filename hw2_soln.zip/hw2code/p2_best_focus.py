import cv2
import numpy as np
import os
import sys

# get the image files from directory
files = [f for f in os.listdir(sys.argv[1])]
# print (files)

# sort by file name
files.sort()

def getEnergy(f): 
    # obtain the full path of a file
    f = os.path.join(sys.argv[1],f)
    img = cv2.imread(f,cv2.IMREAD_GRAYSCALE)
    im_dx = cv2.Sobel(img, cv2.CV_32F, 1, 0)
    im_dy = cv2.Sobel(img, cv2.CV_32F, 0, 1)
    im_dx_sq = np.square(im_dx)
    im_dy_sq = np.square(im_dy)
    sum_dx = np.sum(im_dx_sq)
    sum_dy = np.sum(im_dy_sq)
    return (sum_dx + sum_dy)/(img.shape[0] * img.shape[1])

# calculate energy for each image
max_score = 0
max_file = ''
for f in files:
    score = getEnergy(f)
    print ('%s: %.2f' % (f, score))
    if score > max_score:
        max_score = score
        max_file = f
print ('Image %s is best focused.' % max_file)
