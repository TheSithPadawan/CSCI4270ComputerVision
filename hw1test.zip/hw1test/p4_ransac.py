import cv2         
import numpy as np
import os
import sys

# objective function to calculate the cost given angle and points
def objF(angle, L):
    t = L[:,0]*np.cos(angle) + L[:,1]*np.sin(angle)
    return np.sum(np.square(t))
    
# least square method using orthogonal regression    
def leastsq(newL,comx,comy):
    sum1 = np.sum(newL[:,0]*newL[:,1],axis = 0)
    sum2 = np.sum(np.square(newL[:,0]) - np.square(newL[:,1]))
    # two solutions, theta1, theta2
    fi = np.arctan(2*sum1/sum2)
    theta1 = fi/2
    theta2 = theta1 + (np.pi)/2
    # two rhos
    rho1 = comx*np.cos(theta1) + comy*np.sin(theta1)
    rho2 = comx*np.cos(theta2) + comy*np.sin(theta2)
    # two costs
    cost1 = objF(theta1,newL)
    cost2 = objF(theta2,newL)
    # select the one with lower cost
    if cost1 < cost2:
        optimal = (rho1,theta1)
    else:
        optimal = (rho2,theta2)
    return optimal

# convert the closest point form to implicit form
def convertToIm(r,theta):
    if r < 0: # flip all signs if rho < 0 ==> need to ensure c < 0
        return -np.cos(theta), -np.sin(theta),r
    return np.cos(theta),np.sin(theta),-r
# generate a line of two given points
def generateLine(lst):
    # calculate center of mass
    ret = np.sum(lst, axis = 0)/lst.shape[0]
    newL = lst - np.array([ret[0],ret[1]])
    # call to p3 least square function to get the implicit form of line
    optimal = leastsq(newL,ret[0],ret[1])
    a,b,c = convertToIm(optimal[0],optimal[1])
    return a,b,c
    
# samples = number of iterations
# tau = distance 
# lst is a list of points
def ransac(samples, tau,lst):
    kmax = 0
    stat1 = 0
    stat2 = 0
    bestFit = []
    for i in range(samples):
        # generate two random indices
        sample = np.random.randint(0, len(lst), 2)
        ind1 = sample[0]
        ind2 = sample[1]
        if sample[0] == sample[1]: # skip identical indices
            continue
        # fit a line to the two points chosen
        a,b,c = generateLine(np.array([lst[ind1],lst[ind2]]))
        # decide inliers and outliers based on given parameter tau
        inliers = lst[(lst[:,0]*a + lst[:,1]*b + c)**2 < tau**2]
        outliers = lst[(lst[:,0]*a + lst[:,1]*b + c)**2 >= tau**2]
        k = inliers.shape[0] # number of inliers
        # update current best
        if k > kmax:
            print ('Sample %d:' % i)
            print ('indices (%d,%d)' % (sample[0],sample[1]))
            print ('line (%.3f,%.3f,%.3f)' % (a,b,c))
            print ('inliers %d' % k)
            print ()
            kmax = k
            dist = lambda x,y:abs(a*x+b*y+c)/np.sqrt(a**2+b**2)
            vfunc = np.vectorize(dist)
            inlierDist = np.mean(vfunc(inliers[:,0],inliers[:,1]))
            outlierDist = np.mean(vfunc(outliers[:,0],outliers[:,1]))
            # calculate avg inlier/ outlier distance
            stat1 = inlierDist
            stat2 = outlierDist
            bestFit = [a,b,c]
            
    print ('avg inlier dist %.3f' % stat1)
    print ('avg outlier dist %.3f' % stat2)
    return bestFit
        

if (__name__ == "__main__"):
    # load file and handle args
    lst = np.loadtxt(sys.argv[1])
    if len(sys.argv) == 5:
        np.random.seed(int(sys.argv[-1]))
    samples = int(sys.argv[2])
    tau = float(sys.argv[3])
    bestFit = ransac(samples, tau,lst)
    # helper.graph(lst,bestFit[0],bestFit[1],bestFit[2],'./p4_outimg.jpg')
    
    
    
