import cv2         
import numpy as np
import os
import random
import sys
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt

# graphic function
# input: lst: 2D numpy array of all points 
#        a,b,c: parameters of the implicit form of line
#        outfig: output image file name
def graph(lst,a,b,c,outfig):
    xaxis = lst[:,0]
    yaxis = lst[:,1]
    comx = np.mean(xaxis)
    comy = np.mean(yaxis)
    func = lambda x: (-a/b)*x - c/b
    vfunc = np.vectorize(func)
    ypredict = vfunc(lst[:,0])
    plt.plot(xaxis, ypredict)
    plt.scatter(xaxis, yaxis)
    # center of mass is represented as * in the graph
    plt.plot(comx,comy, 'r*')
    plt.axes().set_aspect('equal', 'datalim')    
    plt.savefig(outfig)

# objective function to calculate the cost given angle and points
def objF(angle, L):
    t = L[:,0]*np.cos(angle) + L[:,1]*np.sin(angle)
    return np.sum(np.square(t))
    
# least square method using orthogonal regression    
def leastsq(newL,comx,comy):
    sum1 = np.sum(newL[:,0]*newL[:,1],axis = 0)
    sum2 = np.sum(np.square(newL[:,0]) - np.square(newL[:,1]))
    # two solutions, theta1, theta2
    fi = np.arctan(2*sum1/sum2)
    theta1 = fi/2
    theta2 = theta1 + (np.pi)/2
    # two rhos
    rho1 = comx*np.cos(theta1) + comy*np.sin(theta1)
    rho2 = comx*np.cos(theta2) + comy*np.sin(theta2)
    # two costs
    cost1 = objF(theta1,newL)
    cost2 = objF(theta2,newL)
    # select the one with lower cost
    if cost1 < cost2:
        optimal = (rho1,theta1)
    else:
        optimal = (rho2,theta2)
    return optimal

# convert the closest point form to implicit form
# using a = cos theta, b = sin theta, r = -rho 
# adjust the signs based on the sign of r
def convertToIm(r,theta):
    if r < 0: # flip all signs if rho < 0 ==> need to ensure c < 0
        return -np.cos(theta), -np.sin(theta),r
    return np.cos(theta),np.sin(theta),-r
    
if (__name__ == "__main__"):
    # load file and args
    lst = np.loadtxt(sys.argv[1])
    tau = float(sys.argv[2])
    outfig = sys.argv[-1]
    print ("min: (%.3f,%.3f)" % (np.amin(lst,axis = 0)[0], np.amin(lst,axis = 0)[1]))
    print ("max: (%.3f,%.3f)" % (np.amax(lst,axis = 0)[0], np.amax(lst,axis = 0)[1]))
    ret = np.sum(lst, axis = 0)/lst.shape[0]
    print ("com: (%.3f,%.3f)" % (ret[0], ret[1]))
    
    # finding the new axis using covariance matrix then PCA
    newL = lst - np.array([ret[0],ret[1]])
    cov = np.cov(newL[:,0],newL[:,1],bias = True)
    w, v = np.linalg.eigh(cov)
    w = np.sqrt(w)
    
    # sorting eigen vectors based on eigen values 
    sort_indices = np.argsort(w)[::-1]
    vec1 = v[:,0]
    vec2 = v[:,1]
    
    # resolving ambiguity by flipping the direction of the vector
    if vec1[0] < 0 or vec1[0] == 0 and vec1[1]<0:
        vec1 = vec1 *(-1)
        
    if vec2[0] < 0 or vec2[0] == 0 and vec2[1]<0:
        vec2 = vec2*(-1)
    optimal = leastsq(newL,ret[0],ret[1])
    
    print ('min axis: (%.3f,%.3f), sd %.3f' % (vec1[0], vec1[1], w[0]))
    print ('max axis: (%.3f,%.3f), sd %.3f' % (vec2[0], vec2[1], w[1]))
    
    print ("closest point: rho %.3f, theta %.3f" % (abs(optimal[0]),optimal[1]))
    a,b,c = convertToIm(optimal[0],optimal[1])
    print ("implicit: a %.3f, b %.3f, c %.3f" % (a,b,c))  
    
    # determine shape
    if (w[0] < tau * w[1]):
        print ("best as line")
    else:
        print ("best as ellipse")
        
    # output the graph
    graph(lst,a,b,c,outfig)
    
