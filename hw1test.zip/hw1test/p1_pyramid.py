import cv2         
import numpy as np
import os
import random
import sys

# generate a bunch of pyramids (1/2, 1/4, .... until condition not met)
# Input: Original Image numpy array
#        x: width; y: height
# Output: a list of pyramids
def generatePy(IM,x,y):
    list_of_pyramids = []
    while True:
        new_x = x//2
        new_y = y//2
        if (new_x<20 or new_y<20):
            break
        py = cv2.resize(IM, (new_y, new_x))
        list_of_pyramids.append(py)
        x = new_x
        y = new_y
    return list_of_pyramids

# main function for problem 1
def p1(fn,out):
    IM = cv2.imread(fn)   
    x = IM.shape[0]
    y = IM.shape[1]
    toDo = generatePy(IM, x, y)
    # calculate shape of the final image
    totalHeight = x
    totalWidth = 0
    for i in range(len(toDo)):
        totalWidth += toDo[i].shape[1]
   
    # keeping track of upperleft coordinates
    start_x = 0
    start_y = 0
    print ("Copy starts at (%d,%d) image shape" % (start_x,start_y), IM.shape)   
    start_y += IM.shape[1]
    # copy each image over to a blank canvas then concatenante with existing ones
    for i in range(len(toDo)):
        print ("Copy starts at (%d,%d) image shape" % (start_x,start_y), toDo[i].shape)   
        blank = np.zeros((totalHeight, toDo[i].shape[1],3),dtype = IM.dtype)
        blank[0:toDo[i].shape[0],0:toDo[i].shape[1]] = toDo[i]          
        start_y +=toDo[i].shape[1]  
        new = np.concatenate((IM, blank),axis = 1)     
        IM = new
    cv2.imwrite(out, new)
    print ("Final shape", new.shape)

if __name__ == "__main__":
    fn = sys.argv[1]
    out = sys.argv[2]
    p1(fn,out)
