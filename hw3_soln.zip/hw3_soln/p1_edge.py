import numpy as np
import cv2
import sys    

def test(im_gm, im_dir):
    # horizontal NMS
    arr = np.copy(im_gm)
    kn = np.array([[0,0,0],[1,1,1],[0,0,0]],dtype = np.uint8)
    DL = cv2.dilate(arr, kn)
    comp = cv2.compare(arr, DL, cv2.CMP_GE)
    ret1 = comp * arr/255 # only peaks should retain
    
    # vertical NMS    
    kn = np.array([[0,1,0],[0,1,0],[0,1,0]],dtype = np.uint8)
    DL = cv2.dilate(arr, kn)
    comp = cv2.compare(arr, DL, cv2.CMP_GE)
    ret2 = comp * arr/255

    # positive diagonal NMS
    kn = np.array([[0,0,1],[0,1,0],[1,0,0]],dtype = np.uint8)
    DL = cv2.dilate(arr, kn)
    comp = cv2.compare(arr, DL, cv2.CMP_GE)
    ret3 = comp * arr/255
    
    # negatvie diagonal NMS
    kn = np.array([[1,0,0],[0,1,0],[0,0,1]],dtype = np.uint8)
    DL = cv2.dilate(arr, kn)
    comp = cv2.compare(arr, DL, cv2.CMP_GE)
    ret4 = comp * arr/255
    
    # pixel replacements
    reg = np.where(im_dir == 100)
    im_gm[reg] = ret1[reg]
    reg = np.where(im_dir == 200)
    im_gm[reg] = ret2[reg]
    reg = np.where(im_dir == 400)
    im_gm[reg] = ret3[reg]
    reg = np.where(im_dir == 300)
    im_gm[reg] = ret4[reg]
    return im_gm

def applyThreshold(out, threshold):
    out[np.where(out<threshold)] = 0 # eliminate the weak edges
    # stretch the max intensity to 255
    gmax = np.max(out)
    gmin = np.min(out)
    out = 255*(out - gmin)/(gmax - gmin)
    return out

def setOrient(a):
    # add 180 degree if angle < 0
    a[np.where(a <0)] += np.pi
    fmap = np.zeros(a.shape)
    fmap[np.where(np.logical_and(a>=0, a<=np.pi/8))] = 100
    fmap[np.where(np.logical_and(a>np.pi/8, a<3*np.pi/8))] = 300
    fmap[np.where(np.logical_and(a>=3*np.pi/8, a<=5*np.pi/8))] = 200
    fmap[np.where(np.logical_and(a>5*np.pi/8, a<7*np.pi/8))] = 400
    fmap[np.where(np.logical_and(a>=7*np.pi/8, a<=np.pi))] = 100
    return fmap
    

def getDirImage(im_dir, im_gm):
    outImg = np.zeros((im_gm.shape[0], im_gm.shape[1],3))
    black = np.array([0,0,0])
    white = np.array([255,255,255])
    blue = np.array([255,0,0]) # actual: BGR
    green = np.array([0,255,0])
    red = np.array([0,0,255]) # actual: BGR

    #d = setOrient(im_dir)
    # draw relevant directions
    outImg[np.where(im_dir==100)] = red
    outImg[np.where(im_dir==300)] = green
    outImg[np.where(im_dir==200)] = blue
    outImg[np.where(im_dir==400)] = white

    # set the border to be black
    outImg[0,:] = black
    outImg[-1,:] = black
    outImg[:,0] = black
    outImg[:,-1] = black
  
    # set the pixels with gradient magnitude < 1.0 to black
    outImg[np.where(im_gm<1.0)] = black
    return outImg

# ok
def getMagImage(im_gm):
    out = np.zeros((im_gm.shape[0], im_gm.shape[1]))
    # map the maximum gradient magnitude to 255
    gmax = np.max(im_gm)
    gmin = np.min(im_gm)
    out = 255*(im_gm - gmin)/(gmax - gmin)
    return out
    
#main
if __name__ == "__main__":
    img = cv2.imread(sys.argv[2], 0)
    sigma = float(sys.argv[1])
    ksize = (int(4*sigma+1),int(4*sigma+1))
    img = np.float32(img)
    im_s = cv2.GaussianBlur(img, ksize, sigma)
   
    # derivative kernels
    kx,ky = cv2.getDerivKernels(1,1,3)
    kx = np.transpose(kx/2)
    ky = ky/2

    im_dx = cv2.filter2D(im_s,-1,kx)
    im_dy = cv2.filter2D(im_s,-1,ky)
    im_gm = np.sqrt( im_dx**2 + im_dy**2)   # gradient magnitude

    im_dir = np.arctan2(im_dy,im_dx)    
    
    # classify orientation
    im_dir = setOrient(im_dir)
    
    # generate direction image
    out1 = getDirImage(im_dir,im_gm)
    
    # generate gradient magnitude image
    out2 = getMagImage(im_gm)

    # non-maximum suppression along all 4 directions
    out = test(im_gm, im_dir)
    # black out the borders
    out[0,:] = 0
    out[-1,:]=0
    out[:,0] = 0
    out[:,-1]=0
    # stats of surviving pixels
    num_surviving_pixels = len(np.where(out>0.1)[0])
    print ('Number after non-maximum:',num_surviving_pixels)
    mean = np.mean(out[np.where(out>=0.1)])
    std = np.std(out[np.where(out>=0.1)])
   

    print ('Average: %.2f' % mean)
    print ('Std dev: %.2f' % std)
    thr = min(mean + std, 10/sigma)
    print ('Threshold: %.2f' % thr)
    
    out3 = applyThreshold(out,thr)
    # stats after thresholding
    x = len(np.where(out3>0)[0])
    print ('Number after threshold:', x)

    # saving output images    
    cv2.imwrite(sys.argv[2].split('.')[0]+'_dir.png',out1)
    cv2.imwrite(sys.argv[2].split('.')[0]+'_grd.png',out2)
    cv2.imwrite(sys.argv[2].split('.')[0] + '_thr.png', out3)
   
