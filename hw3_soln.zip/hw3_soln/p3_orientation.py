import numpy as np
import cv2
import sys
import itertools

'''
Image Derivatives:
-- borrowed from Prof Stewart's Lecture Demo
'''
def dxdy(sigma, img):
   ksize = (int(4*sigma+1),int(4*sigma+1))
   img = img.astype(np.float32)
   im_s = cv2.GaussianBlur(img, ksize, sigma)
   # derivative kernels
   kx,ky = cv2.getDerivKernels(1,1,3)
   kx = np.transpose(kx/2)
   ky = ky/2
   im_dx = cv2.filter2D(im_s,-1,kx)
   im_dy = cv2.filter2D(im_s,-1,ky)
   im_gm = np.sqrt( im_dx**2 + im_dy**2)   # gradient magnitude
   im_dir = np.arctan2(im_dy,im_dx) # in range [-pi, pi]
   return im_gm, im_dir

'''
Calculating weight: a combination of Gauss Function 
and Gradient Magnitude
'''
def wt(im_gm, kp_loc, width, sigma_v):
    kp_x = kp_loc[0]
    kp_y = kp_loc[1]
    # generate all the points within the 17*17 block
    region_x = [x for x in range(kp_x-width//2, kp_x + width//2+1)]
    region_y = [y for y in range(kp_y-width//2, kp_y + width//2+1)]
    pts = np.array(list(itertools.product(region_x, region_y)))
    assert(pts.shape[0] == width**2)
    coefs = cv2.getGaussianKernel(width, sigma_v)
    coefs_mat = np.outer(coefs, coefs)
    # second part of weight by getting the gradient magnitude of the region
    region_mag = im_gm[kp_x-width//2:kp_x+width//2+1, kp_y-width//2:kp_y+width//2+1]
    # finally multiply them together and return a weight matrix -- element wise multiplication
    weight = coefs_mat * region_mag
    return weight

'''
Actual Voting Process
'''
def voting(weight, im_dir, width, kp_loc):
    kp_x = kp_loc[0]
    kp_y = kp_loc[1]
    hist = np.zeros((36,))
    region_angle = im_dir[kp_x-width//2:kp_x+width//2+1, kp_y-width//2:kp_y+width//2+1]
    # for each angle in the region, first determine which bin it belongs to
    bin_loc = (region_angle + np.pi)//(np.pi/18) # step = 10 degree, which is pi/18 radian
    # convert to integer data typesfor the purpose of indexing
    bin_loc = bin_loc.astype(int)
    # calculate offset for each angle and the bin it belongs to 
    offset = (region_angle + np.pi - (bin_loc+0.5)*(np.pi/18))/(np.pi/18)
    # then assign weight to the two bins in the histogram
    # loop through each pixel in the region
    for i in range(width):
        for j in range(width):
            if (offset[i,j]<0):
                share = (bin_loc[i,j] + 36 -1)% 36 # this is the other bin
            else:
                share = (bin_loc[i,j]+1)% 36
            hist[share] += weight[i,j]*abs(offset[i,j])
            hist[bin_loc[i,j]] += weight[i,j]*(1-abs(offset[i,j]))
    return hist

'''
Apply smoothing to histogram 
'''
def smooth_histogram(hist):
    h2 = np.zeros(hist.shape)
    M = hist[1:-1]
    L = hist[0:-2]
    R = hist[2:]
    tmp = (L + R)/2
    h2[1:-1] = (M + tmp)/2
    h2[0] = (hist[0]+ (hist[1]+hist[-1])/2)/2
    h2[-1] = (hist[-1] + (hist[-2] + hist[0])/2)/2
    return h2

'''
Pretty print of the histogram
'''
def print_histogram(h1, h2):
    init = -180
    for i in range(h1.shape[0]):
        print('[{:d},{:d}]: {:.2f} {:.2f}'.format(init,init+10,h1[i], h2[i]))
        init += 10

# finding peaks before interpolation
# using code from hw2...
def peak_finding (a):
    is_max = np.zeros_like(a, dtype=np.bool)
    left = a[ :-2]
    right = a[ 2: ]
    center = a[ 1:-1 ]
    is_max[ 1:-1 ] = (center > right) * (center > left)
    is_max[0] = (a[0] > a[1]) and (a[0] > a[-1])
    is_max[-1] = (a[-1] > a[-2]) and (a[-1] > a[0])
    return np.where(is_max)[0]

'''
Interpolate on the histogram to localize
the actual orientation and peak height
'''
def interpolate(h):
    peak_loc = peak_finding(h)
    L = peak_loc-1
    R = peak_loc+1
    # protective step
    R[np.where(R == h.shape[0])] = 0
    bs = (h[R] - h[L])/2
    twoA = h[R] + h[L] - 2*h[peak_loc]
    As = twoA/2
    offset = -bs/twoA
    offset *= 10
    middle = -180 + (peak_loc+0.5)*10
    middle += offset
    #np.set_printoptions(precision=2)
    peak_vals = -bs**2/(2*twoA) + h[peak_loc]
    # zip the angles and values together
    pairs = np.vstack([middle, peak_vals]).T
    # sort by second column: peak values
    pairs = pairs[np.argsort(pairs[:,1])]
    # threashold on peak values to be 1% of max peak height
    peaks_indices = np.where(pairs[:,1]>=0.01*np.max(pairs[:,1]))
    angles = pairs[:,0][peaks_indices][::-1] # ranked by lowering peaks
    peaks = pairs[:,1][peaks_indices][::-1] # ranked by lowering peaks
    return angles, peaks

# main
if __name__ == "__main__":
    sigma = float(sys.argv[1])
    IM = cv2.imread(sys.argv[2], 0) # read in grayscale
    kp = np.loadtxt(sys.argv[3],dtype = int) # read the points locations
    sigma_v = int(2*sigma) # used for voting
    region_width = int(4*sigma_v + 1)
    # first calculate derivative
    im_gm, im_dir = dxdy(sigma, IM)
    # weighted voting begins here
    for i in range(kp.shape[0]):
        print ()
        print (' Point {:d}: ({:d},{:d})'.format(i, kp[i][0], kp[i][1]))
        print ('Histograms:')
        weight = wt(im_gm, kp[i], region_width, sigma_v)
        hist = voting(weight, im_dir, region_width, kp[i])
        hist2 = smooth_histogram(hist)
        print_histogram(hist, hist2)
        angles, peaks = interpolate(hist2)
        for i in range(angles.shape[0]):
            print ('Peak {:d}: theta {:.1f}, value {:.2f}'.format(i, angles[i], peaks[i]))
        print ('Number of strong orientation peaks:', len(np.where(peaks>=0.8*np.max(peaks))[0]))
