import numpy as np
import cv2
import sys

# im must be grayscale
# return top 100/200 Harris keypoints
def computeHARRIS(sigma, im, num_kps):
    ksize = (int(4*sigma+1),int(4*sigma+1))
    im_s = cv2.GaussianBlur(im.astype(np.float32), ksize, sigma)
    kx,ky = cv2.getDerivKernels(1,1,3)
    kx = np.transpose(kx/2)
    ky = ky/2

    '''  Derivatives '''
    im_dx = cv2.filter2D(im_s,-1,kx)
    im_dy = cv2.filter2D(im_s,-1,ky)

    ''' Components of the outer product '''
    im_dx_sq = im_dx * im_dx
    im_dy_sq = im_dy * im_dy
    im_dx_dy = im_dx * im_dy

    ''' convolve with weighted average'''
    h_sigma = 2*sigma
    h_ksize = (int(4*h_sigma+1),int(4*h_sigma+1))
    im_dx_sq = cv2.GaussianBlur(im_dx_sq, h_ksize, h_sigma)
    im_dy_sq = cv2.GaussianBlur(im_dy_sq, h_ksize, h_sigma)
    im_dx_dy = cv2.GaussianBlur(im_dx_dy, h_ksize, h_sigma)

    ''' Compute the Harris measure '''
    kappa = 0.04
    im_det = im_dx_sq * im_dy_sq - im_dx_dy * im_dx_dy
    im_trace = im_dx_sq + im_dy_sq
    im_harris = im_det - kappa * im_trace*im_trace

    '''renormalize intensity'''
    i_min = np.min(im_harris)
    i_max = np.max(im_harris)
    im_harris = 255 * (im_harris - i_min) / (i_max-i_min)

    '''NMS'''
    max_dist = int(2*sigma) # 4
    kernel = np.ones((2*max_dist+1,2*max_dist+1),np.uint8)
    im_harris_dilate = cv2.dilate(im_harris, kernel)

    im_peaks = cv2.compare(im_harris, im_harris_dilate, cv2.CMP_GE) # all peaks are put into 255
    im_peaks = (im_peaks) * (im_harris)/255

    ''' Ordering and Storing Results'''
    oneD = im_peaks.flatten()
    loc = oneD.argsort()[::-1] # sorting response value from large to small
    i,j = np.unravel_index(loc, im_peaks.shape)
    
    ''' Put them into the keypoint list '''
    harris_keypoints = []
    kp_size = 4*sigma
    for t in range(len(i)):
        harris_keypoints.append(cv2.KeyPoint(j[t],i[t], kp_size, -1, im_peaks[i[t], j[t]]))

    # filter out points that have intenstiy = 0
    harris_keypoints = [x for x in harris_keypoints if x.response > 0]
    return harris_keypoints[0:num_kps]

# Compute SIFT keypoints using cv function
def computeSIFT(sigma, im, num_kps):
    sift = cv2.xfeatures2d.SIFT_create()
    kp = sift.detect(im,None)
    # filter out sizes > 3 sigma
    kp = [x for x in kp if x.size <= 3*sigma]
    kp.sort( key = lambda k: k.response) # sorted by response
    kp = kp[::-1]
    #out_img = cv2.drawKeypoints( im.astype(np.uint8), kp, None)

    # filter repeated keypoints
    kp_unique = [kp[0]]
    for k in kp[1:]:
        if k.pt != kp_unique[-1].pt:
            kp_unique.append( k )
            
    # return a list containing number of keypoints specified by the user
    # the list is sorted by response 
    return kp_unique[0:num_kps]

# Pretty print
def printStat(top5, type_of_kp):
    print ()
    if type_of_kp == 'SIFT':
        print ('Top 5 SIFT keypoints:')
    elif type_of_kp == 'HARRIS':
        print ('Top 5 Harris keypoints:')
    for i in range(len(top5)):
        print ('{:d}: ({:.2f}, {:.2f}) {:.4f}'.format(i,top5[i].pt[0], top5[i].pt[1], top5[i].response))
    
# finding the closest keypoints and compute the min distances
def closest_kp(L1, L2):
    loc1 = np.array([[kp.pt[0], kp.pt[1]] for kp in L1])
    #print (loc1)
    loc2 = np.array([[kp.pt[0], kp.pt[1]] for kp in L2])
    #print (loc2)
    min_dst = []
    ranks = []
    for i in range(loc1.shape[0]):
        dist = []
        for j in range(loc2.shape[0]):
            t = np.linalg.norm(loc2[j] - loc1[i])
            dist.append(t)# compute all distances
        # find min distance
        dist = np.array(dist)
        min_pos = dist.argmin()
        min_val = dist[min_pos]
        min_dst.append(min_val)
        ranks.append(abs(i - min_pos))
    assert (len(min_dst) == loc1.shape[0])
    # again, vectorize
    min_dst = np.array(min_dst)
    ranks = np.array(ranks)
    
    # print some stats
    print ('num_from 100 num_to %d' % len(L2))
    print ('Median distance: %.1f' %np.median(min_dst))
    print ('Average distance: %.1f' %np.mean(min_dst))
    print ('Median index difference: %.1f' % np.median(ranks))
    print ('Average index difference: %.1f' % np.mean(ranks))
    
# main
# demo
if __name__ == "__main__":
    IM = cv2.imread(sys.argv[2],cv2.IMREAD_GRAYSCALE)
    sigma = float(sys.argv[1])
    top200_harris = computeHARRIS(sigma, IM,200)
    printStat(top200_harris[0:5], 'HARRIS')
    top200_sift = computeSIFT(sigma, IM,200)
    printStat(top200_sift[0:5], 'SIFT')
    print ()
    print ('Harris keypoint to SIFT distances:')
    closest_kp(top200_harris[0:100], top200_sift[0:200])
    print()
    print ('SIFT keypoint to Harris distances:')
    closest_kp(top200_sift[0:100], top200_harris[0:200])
    # produce output images
    out_img = cv2.drawKeypoints( IM.astype(np.uint8), top200_harris[0:100], None)
    cv2.imwrite(sys.argv[2].split('.')[0]+'_harris.jpg',out_img)
    out_img = cv2.drawKeypoints( IM.astype(np.uint8), top200_sift[0:200], None)
    cv2.imwrite(sys.argv[2].split('.')[0]+'_sift.jpg',out_img)



