import cv2
import numpy as np
import sys
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans

'''
utility functions
'''
def drawPoints(Flag, Img, Points, Color):
    for i in range(Points.shape[0]):
        # generate random color
        if Flag == False:
            color = np.random.uniform(low = 0, high=255,size = 3)
        else:
            color = Color
        pt = Points[i]
        Img = cv2.circle(Img,(pt[0],pt[1]),6,color,thickness = 1)
    return Img

def drawArrows(Img, From, To, Color):
    assert(From.shape == To.shape)
    for i in range(From.shape[0]):
        Img = cv2.arrowedLine(Img, tuple(From[i]),tuple(To[i]),Color,thickness=2)
    return Img

'''
draw each classified cluster
and the bounding rectangle
'''
def drawClusters(cluster_num,out_start, out_end, canvas, color):
    index = np.where(label_map == cluster_num)[0]
    cluster = []
    start = []
    for i in range(index.shape[0]):
        cluster.append(out_end[index[i]])
        start.append(out_start[index[i]])
    cluster = np.vstack((cluster))
    start = np.vstack((start))
    canvas = drawPoints(True, canvas, cluster, color)
    canvas = drawArrows(canvas, start, cluster, color)
    min_x = int(np.amin(cluster, axis = 0)[0])
    min_y = int(np.amin(cluster, axis = 0)[1])
    max_x = int(np.amax(cluster, axis = 0)[0])
    max_y = int(np.amax(cluster, axis = 0)[1])
    canvas = cv2.rectangle(canvas, (min_x-3,min_y-3),(max_x+3,max_y+3),color,2)
    return canvas

'''
using ransac to get a set of inliers vectors for FOE estimation
'''
def ransac(start, end):
    kmax = 0
    bestModel = (0,0)
    '''
    ransac hyperparameters:
    let p(success) = 0.995
    w = 0.4
    max iter = ln(1-p)/ln(1-w^2) = 30.38
    '''
    maxIter = 35
    vectors = end - start
    for i in range(maxIter):
        # generate two random indices
        sample = np.random.randint(0,vectors.shape[0],2)
        ind1 = sample[0]
        ind2 = sample[1]
        if sample[0] == sample[1]:
            continue
        # find intersection of two vectors --> maybe FOE
        maybeFOE = getIntersect(start[ind1],end[ind1],start[ind2],end[ind2])

        # checks for invalid values possibly caused by inverting a singular matrix
        mask1 = np.isinf(maybeFOE)
        if np.any(mask1):
            print ('inf caught')
            continue
        mask2 = np.isnan(maybeFOE)
        if np.any(mask2):
            print ('nan caught')
            continue

        # checks to ensure FOE is in image plane --> that is the assumption
        if (maybeFOE[0] < 0 or maybeFOE[1] < 0 or maybeFOE[0]>Y or maybeFOE[1] > X):
            if (maybeFOE[0]>Y or maybeFOE[1]>X):
                print ('invalid FOE -- FOE outside image plane')
                maxIter -= 1
            continue
        
        # use this FOE to fit the rest of the lines
        # the line = vx-uy = x1v-y1u; with a = v, b = -u
        inliers = 0
        index = []
        for i in range(vectors.shape[0]):
            dist = lambda x,y:abs(a*x+b*y+c)/np.sqrt(a**2+b**2)
            vfunc = np.vectorize(dist)
            a = vectors[i][1] # v
            b = -vectors[i][0]# -u
            c = end[i][0]*start[i][1]-start[i][0]*end[i][1]
            distance = vfunc(maybeFOE[0], maybeFOE[1])
            if (distance <3): # allow for 10 pixel miss
                inliers += 1
                index.append(i)
        
        if inliers > kmax:
            kmax = inliers
            bestModel = (maybeFOE[0], maybeFOE[1])
            inliers_start = []
            inliers_end = []
            outliers_start = []
            outliers_end = []
            out_index = [x for x in range(vectors.shape[0]) if x not in index]
            for u in index: 
                inliers_start.append(start[u])
                inliers_end.append(end[u])
            for v in out_index:
                outliers_start.append(start[v])
                outliers_end.append(end[v])
            inliers_start = np.vstack((inliers_start))
            inliers_end = np.vstack((inliers_end))
            outliers_start = np.vstack((outliers_start))
            outliers_end = np.vstack((outliers_end))
    print ('ransac: max number of inliers %d' % kmax)
    print ('FOE Estimate Using Ransac Best Inliers', bestModel)
    return inliers_start, inliers_end, outliers_start,outliers_end
    
'''
calculate the intersection point between two 
parametric line equations
'''
def getIntersect(p0,p1,q0,q1):
    mat = np.zeros((2,2))
    mat[:,0] = (p1-p0)
    mat[:,1] = -(q1-q0)
    b = (q0-p0)
    soln = np.dot(np.linalg.inv(mat),b)
    return p0 + soln[0]*(p1-p0)

'''
compute the final FOE using least square of all inliers
'''
def leastsq(in_start, in_end):
    A = np.zeros(in_start.shape)
    vects = in_end - in_start
    A[:,0] = vects[:,1]
    A[:,1] = -vects[:,0]
    b = in_start[:,0]*vects[:,1] - in_start[:,1]*vects[:,0]
    FOE = np.dot(np.linalg.inv(np.dot(A.T,A)), np.dot(A.T, b))
    return FOE
    
if __name__ == "__main__":
    Im1 = cv2.imread(sys.argv[1])
    Im2 = cv2.imread(sys.argv[2])
    copy = np.copy(Im2)
    X = Im2.shape[0]
    Y = Im2.shape[1]
    
    # params for ShiTomasi corner detection
    feature_params = dict( maxCorners = 200,
                       qualityLevel = 0.6,
                       minDistance = 7,
                       blockSize = 3 )
    
    # KLT algo parameters
    lk_params = dict( winSize  = (7,7),
                  maxLevel = 5,
                  criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
    Im1_gray = cv2.cvtColor(Im1, cv2.COLOR_BGR2GRAY)
    Im2_gray = cv2.cvtColor(Im2, cv2.COLOR_BGR2GRAY)
    print ('Computing motion on feature points...')
    p0 = cv2.goodFeaturesToTrack(Im1_gray, mask = None, **feature_params)
    p1, st, err = cv2.calcOpticalFlowPyrLK(Im1_gray, Im2_gray, p0, None, **lk_params)
    print ('Total number of feature points obtained %d' % p0.shape[0])
    # select points which flows are found
    good_Im2 = p1[st==1]
    good_Im1 = p0[st==1]
    vectors = good_Im2 - good_Im1
    print ('Total number of feature points with motion %d' % good_Im1.shape[0])
    
    # thresholding: get rid of really big and really small vectors -- probably due to error
    norms = np.linalg.norm(vectors,axis = 1)
    # motion should be > 1 pixel
    good_Im1 = good_Im1[np.where(norms>1)]
    good_Im2 = good_Im2[np.where(norms>1)]
    # motion should be < 10 pixel
    #good_Im1 = good_Im1[np.where(norms<10)]
    #good_Im2 = good_Im2[np.where(norms<10)]
    print ('Total number of feature points after thresholding %d' % good_Im1.shape[0])

    print ('Ransac filtering inliers...')
    in_start, in_end, out_start, out_end = ransac(good_Im1,good_Im2)
    # determine if there exists camera motion using number of inlier as criteria
    # need at least 2 points to prove camera motion
    if (in_start.shape[0] <= 4):
        print ('No camera motion detected because of not enough inliers')
        print ('Exptected %d; Actual %d' % (5, in_start.shape[0]))
        out = drawPoints(False, Im2, good_Im2,(0,0,0))
    else:
    # least square estimate using inliers set
        FOE = leastsq(in_start, in_end)
        print ('FOE Estimated Using Least Square of Inliers',FOE)

        # Generate Output Images
        # Output image 1 with feature points and arrows, FOE drawn on top
        out = cv2.circle(Im2,(int(FOE[0]),int(FOE[1])),10,(0,0,255),thickness = -1)
        out = drawPoints(False, out,good_Im2,(0,0,0))
    # red arrow --> outliers; blue arrow --> inliers
    out = drawArrows(out, out_start, out_end, (0,0,255))
    out = drawArrows(out, in_start, in_end,((0,255,0)))
    cv2.imwrite('output_01.jpg', out)
    
    # k-mean clustering of outlier points (ind moving objects)
    kmeans = KMeans(n_clusters = 3,random_state = 0).fit(out_start)
    label_map = kmeans.labels_
  
    
    # produce the second output
    # draw points, arrows on each cluster using same color
    #out2 = cv2.circle(Im2,(int(FOE[0]),int(FOE[1])),10,(0,0,255),thickness = -1)
    out2 = copy
    for i in range(3):
        color = np.random.uniform(low = 0, high=255,size = 3)    
        out2 = drawClusters(i, out_start, out_end, out2,color)
    cv2.imwrite('output_02.jpg',out2)

