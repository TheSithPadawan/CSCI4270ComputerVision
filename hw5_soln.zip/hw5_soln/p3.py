import numpy as np
import cv2
import sys
import os
from matplotlib import pyplot as plt
import pickle
from sklearn.svm import LinearSVC
import argparse
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
import itertools
from sklearn.model_selection import GridSearchCV


# some global parameters here
T = 16
Bw = 4
Bh = 4

'''
unpickle each classifier
'''
def loadClassifier(category):
     with open (os.path.join(parser['SVMFiles'],category+"_classifier.pickle"),'rb') as C:
         classifier = pickle.load(C)
     return classifier

'''
compute features for each image
'''
def getFeatures(Dir):
    categories = [name for name in os.listdir(Dir) if os.path.isdir(os.path.join(Dir, name))]
    testData = []
    testLabels = []
    
    for test in categories:
        path = os.path.join(Dir,test)
        for f in os.listdir(path):
             Image = cv2.imread(os.path.join(path,f))
             hist = computeHist(Image)
             testData.extend(hist.reshape((1, hist.shape[0])))
             if (test=="grass"):
                 testLabels.append(0)
             elif (test == "ocean"):
                 testLabels.append(1)
             elif (test == "redcarpet"):
                 testLabels.append(2)
             elif (test == "road"):
                 testLabels.append(3)
             elif (test == "wheatfield"):
                 testLabels.append(4)
    testData = np.array(testData)
    testLabels = np.array(testLabels)
    return testData, testLabels

'''
Pickle computed features
so no need to compute again between runs
'''
def pickleFeatures(pkDir, dsDir):
     categories = [name for name in os.listdir(dsDir) if os.path.isdir(os.path.join(dsDir,name))]
     for cat in categories:
        fn = cat + ".pickle"
        path = os.path.join(dsDir,cat)
        with open(os.path.join(pkDir,fn), 'wb') as vectorFile:
            for f in os.listdir(path):
                Image = cv2.imread(os.path.join(path,f))
                hist = computeHist(Image)
                pickle.dump(hist, vectorFile)
        print ("Finished processing Folder %s" % cat)

'''
- unpickle featuers and train 5 SVM
- brute force search for 'optimal' hyperparameter
'''
def trainSVM(outPickleDir, vecDir):
    features = []
    labels = []
    cats = ['grass','ocean','redcarpet','road','wheatfield']
    for i in range(len(cats)): # load features from each class
        with open(os.path.join(vecDir,cats[i]) + '.pickle',"rb") as F:
            while True:
                try:
                    features.append(pickle.load(F))
                    labels.append(i)
                except EOFError:
                    break

    features = np.array(features)
    labels = np.array(labels)
    for k in range(5): # 5 classes
        # label encoding for each class
        label = np.copy(labels)
        label[np.where(labels == k)] = 1
        label[np.where(labels != k)] = -1
        print ("training for SVM Classifier for class %s" % cats[k])
        # training SVM for each class and save as pickles
        # parameter tuning
        grid = [{'C':[0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8,8.5,9,9.5,10]}]
        M = GridSearchCV(LinearSVC(), grid, scoring= 'accuracy',cv=5)
        #print (svm.get_params().keys())
        M.fit(features, label)
        print("Best parameters set found on development set:")
        print (M.best_params_)
        model = LinearSVC(C = M.best_params_['C'])
        model.fit(features, label)
        print ('accuracy after tuning %.4f' % model.score(features, label))
        outpath = os.path.join(outPickleDir,cats[k] + "_classifier.pickle")
        with open (outpath,'wb') as f:
            pickle.dump(model,f)

'''
get the upper left coordinates for each block
'''
def getBlocks(del_w, del_h, W, H):
    px, py = np.mgrid[0:(W-del_w):del_w, 0:(H-del_h):del_h]
    points = np.c_[px.ravel(), py.ravel()] # points are ordered by [w_i, h_i]
    points = points.astype(np.uint8)#indices must be integer
    return points

'''
compute 3D color histogram
and concatenate for each image
'''
def computeHist(img):
    delW = img.shape[1]//(Bw + 1)
    delH = img.shape[0]//(Bh + 1)
    blocks = getBlocks(delW, delH, img.shape[1], img.shape[0])
    assert(blocks.shape[0] == Bw * Bh)
    compiled_hist = []
    for i in range(blocks.shape[0]):
        mask = np.zeros(img.shape[:2], np.uint8)
        mask[blocks[i,1]:blocks[i,1]+2*delH,blocks[i,0]:blocks[i,0]+2*delW] = 255 
        #masked_img = cv2.bitwise_and(img, img, mask = mask)
        hist = cv2.calcHist([img], [0,1,2], mask, [T,T,T], [0,256,0,256,0,256]) 
        compiled_hist.extend(hist.flatten())
    # get the final descriptor for the whole image
    compiled_hist = np.array(compiled_hist)
    return compiled_hist

'''
plotting confusion matrix
'''
def plot_confusion_matrix(mat, classes):
    plt.imshow(mat, interpolation = 'nearest')
    plt.title("Confusion Matrix")
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    thresh = mat.max()/2
    for i, j in itertools.product(range(mat.shape[0]), range(mat.shape[1])):
        plt.text(j, i, format(mat[i, j], 'd'),
                 horizontalalignment="center",
                 color="white" if mat[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')

if __name__ == "__main__":
    # command line args
    arg = argparse.ArgumentParser()
    arg.add_argument("-train",help="True if to train SVM, False if not")
    arg.add_argument("-test", help = "True if to test SVM, False if not")
    arg.add_argument("--vectorFiles",help = "Path to the vector pickles")
    arg.add_argument("--SVMFiles", help = "Path to the SVM pickles")
    arg.add_argument("--trainSet",  help="Path to the training data set")
    arg.add_argument("--testSet", help = "Path to the test data set")
    arg.add_argument('--load', help = "True if load existing features, False to compute features")
    arg.add_argument('--testOneImage', help = "True if only testing one image")
    arg.add_argument('--label',help = 'label of the image (only need when testOneImage is True)')
    parser = vars(arg.parse_args())
    
    if (parser['train']): # training
        # compute and pickle features for each class
        if (int(parser["load"]) == 0):
            print ('computing local color histogram')
            pickleFeatures(parser['vectorFiles'], parser['trainSet'])
        # train and pickle SVM for each class
        trainSVM(parser['SVMFiles'], parser['vectorFiles'])
    
    if (parser['test']): # testing
        if (int(parser["testOneImage"]) == 1):
             Im = cv2.imread(parser['testSet'])
             Xs = computeHist(Im)
        else:
             # load data from test path
             # Xs: features Mat; Ys: labels Vector
             if (os.path.isfile('testData.pickle')):
                  with open ('testData.pickle','rb') as f:
                       Xs = pickle.load(f)
             else:
                  print('computing test set features')
                  Xs, Ys = getFeatures(parser['testSet'])
                  with open ('testData.pickle','wb') as f:
                       pickle.dump(Xs, f)

             if (os.path.isfile('testLabel.pickle')):
                  with open ('testLabel.pickle','rb') as f:
                       Ys = pickle.load(f)
             else:
                  with open ('testLabel.pickle','wb') as f:
                       pickle.dump(Ys, f)
        
        # load each classifier
        cats = ['grass','ocean','redcarpet','road','wheatfield']
        weightMat = []
        biasVec = []
        norms = []
        for i in range(5):
            print ("loading %s classifier" % cats[i])
            classifier = loadClassifier(cats[i])
            weight = classifier.coef_
            weightMat.append(weight.T)
            norms.append(np.linalg.norm(weight))
            bias = classifier.intercept_
            biasVec.append(bias)
        weightMat = np.hstack((weightMat))
        biasVec = np.array(biasVec)
        norms = np.array(norms)
        
        # calculate scores
        result = np.dot(Xs, weightMat)
        result += bias.T # add the bias via broadcasting
        result /= norms.T # normalizing by weight via broadcasting
      
        if (int(parser['testOneImage']) == 1):
             predicts = np.argmax(result)
             print (result)
             print ('predicted result', cats[predicts])
        else:
             # computing scores by taking the max index of each row
             predicts = np.argmax(result,axis = 1)
             print ('prediction accuracy %.4f' % accuracy_score(Ys, predicts))
             cnf_matrix = confusion_matrix(Ys, predicts)
             plt.figure()
             plot_confusion_matrix(cnf_matrix,cats)
             plt.savefig('confusion_matrix.jpg')
        
