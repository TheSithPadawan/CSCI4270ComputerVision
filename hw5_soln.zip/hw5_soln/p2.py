import numpy as np
import cv2
import sys
from sklearn.cluster import KMeans

'''
preprocessing before kmeans
'''
# current feature vector [B, G, R, X, Y, Light Intensity]
def extractFeatureVector(IM, LAB, STD):# concatenate RGB and pixel location
    Features = []
    for i in range(IM.shape[0]):
        for j in range(IM.shape[1]):# IM[i,j] 1D, 3 element array
            vec = np.concatenate((IM[i,j],np.array([i,j]), LAB[i,j], STD[i,j]))
            #vec = np.concatenate((IM[i,j],np.array([i,j])))
            Features.append(vec)
    return np.array(Features)

'''
Image relabeling: relabel
each pixel by the centroid intensity 
of the cluster it belongs to
'''
def getOutput(image,labels,num_clusters,centroids):
    output = np.copy(image)
    for i in range(num_clusters):
        output[np.where(labels == i)] =centroids[i][:3]
    cv2.imwrite('labeledImage.jpg',output)

'''
Compute the standard deviation
of each color channel over a 
3*3 neighborhood
'''
def computeStd(img):
    out = np.zeros((img.shape))
    for i in range(img.shape[0]):
        region = []
        for j in range(img.shape[1]): # kind of wrap around
            k = j+1
            t = i+1
            if i == 0 or i == img.shape[0]-1:
                t = 0
            if j == 0 or j == img.shape[1]-1:
                k = 0
            region.append(img[i,j-1])
            region.append(img[i,k])
            region.append(img[i-1,j])
            region.append(img[t,j])
            region.append(img[i,j])
            vals = np.array(region)
            out[i, j] = np.std(np.asarray(region),axis = 0)
    return out


if __name__ == "__main__":
    image = cv2.imread(sys.argv[1])
    # convert to LAB space
    imageLAB = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    num_clusters = int(sys.argv[2])
    std = computeStd(image)
    data = extractFeatureVector(image, imageLAB, std)
    # using Sklearn kmean, with intialization method default to kmean++
    kmeans = KMeans(n_clusters = num_clusters)
    kmeans = kmeans.fit(data)
    labels = kmeans.predict(data)
    # reshaping labels
    labels = labels.reshape((image.shape[0], image.shape[1]))
    centroids = kmeans.cluster_centers_
    #print (centroids)
    # produce output
    getOutput(image, labels, num_clusters,centroids)
    
