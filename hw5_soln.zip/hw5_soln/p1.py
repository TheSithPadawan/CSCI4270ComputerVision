import cv2
import numpy as np
import sys

'''
given file name,
return 3 lists, the bounding box, the foreground rects and the background rects
'''
def readInput(fn):
    bounding = []
    fg = []
    bg = []
    with open (fn) as f:
        for line in f:
            line = line.strip()
            if (line[0] == 'o'):
                chars = line.split()[1:]
                bounding = chars
            elif (line[0] == 'f'):
                chars = line.split()[1:]
                chars = [int(ch) for ch in chars]
                fg.append(chars)
            elif (line[0] == 'g'):
                chars = line.split()[1:]
                chars = [int(ch) for ch in chars]
                bg.append(chars)
    bounding = [int(x) for x in bounding]
    return bounding, fg, bg

'''
drawing function using opencv rectangle
'''
def drawRec(img,uL,lR, color):
    output = cv2.rectangle(img, uL, lR, color)
    return output

def drawInnerRect(img, L, color):
    for l in L:
        out = drawRec(img, (l[0],l[1]),(l[2],l[3]),color)
        img = out
    return img

'''
certain region of the mask is reset to the 
new value specified by caller
'''
def adjustMask(mask, L, newVal):
    for l in L:
        mask[l[1]:l[3]+1, l[0]:l[2]+1] = newVal
    return mask

if __name__ == '__main__':
    img = cv2.imread(sys.argv[1])
    im2 = np.copy(img)
    outer, fg, bg = readInput(sys.argv[2])
    
    # draw rectangles
    outImg = drawRec(img, (outer[0], outer[1]), (outer[2],outer[3]),(255,0,0))
   
    outImg = drawInnerRect(outImg, fg, (0,255,0))
    outImg = drawInnerRect(outImg, bg, (0,0,255))
    cv2.imwrite('rects_label.jpg', outImg)
    
    # actual grab cut algo
    mask = np.zeros(im2.shape[:2],np.uint8)
    bgdModel = np.zeros((1,65),np.float64)
    fgdModel = np.zeros((1,65),np.float64)
    
    # initialize with rectangle then give some touch up using the inner rectangles
    outerRec = (outer[0], outer[1], outer[2], outer[3])
    cv2.grabCut(im2,mask,outerRec,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_RECT)
    mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')
    im2 = im2*mask2[:,:,np.newaxis]
    cv2.imwrite('initial.jpg',im2)
    
    # adjustment for sure foreground/background
    mask = adjustMask(mask, fg, 1)
    mask = adjustMask(mask, bg, 0)

    mask, bgdModel, fgdModel = cv2.grabCut(im2,mask,None,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_MASK)
    # black out the background
    mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')
    im2 = im2*mask2[:,:,np.newaxis]
    cv2.imwrite('after1.jpg',im2)
    
