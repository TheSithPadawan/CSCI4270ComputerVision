import sys
import os
import cv2
import numpy as np
import torch
from torch.autograd import Variable
from sklearn.model_selection import train_test_split # cross validation
import torch.nn as nn
import torch.nn.functional as F
import pickle
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
import itertools

# network architecture:
# One input layer; one output layer; one hidden layer
input_size = 3072
hidden_size = 500
output_size = 5

def loadData(Dir,loadTrain = True):
    cats = ['grass','ocean','redcarpet','road','wheatfield']
    Xs = []
    Ys = []
    for i in range(len(cats)):
        path = os.path.join(Dir, cats[i])
        for f in os.listdir(path):
            Image = cv2.imread(os.path.join(path,f))
            Resized_Im = cv2.resize(Image, (256,256),interpolation = cv2.INTER_CUBIC)
            X = Resized_Im.flatten()
            Y = np.zeros(5)
            Y[i] = 1
            Xs.append(Resized_Im)
            Ys.append(Y)
    X_data = np.vstack((Xs))
    Y_data = np.vstack((Ys))
    if loadTrain == True: # process and load training data
        X_train,X_valid,Y_train,Y_valid = train_test_split(X_data,Y_data,test_size = 0.2)
        # convert to tensor
        X_train = Variable(torch.from_numpy(X_train).float())
        Y_train = Variable(torch.from_numpy(Y_train).float())
        X_valid,Y_valid = Variable(torch.from_numpy(X_valid).float()),Variable(torch.from_numpy(Y_valid).float())
        with open ("./data_pickles/trainX.pickle",'wb') as f:
            pickle.dump(X_train,f)
        with open ("./data_pickles/trainY.pickle",'wb') as f:
            pickle.dump(Y_train,f)
        with open ("./data_pickles/validX.pickle",'wb') as f:
            pickle.dump(X_valid, f)
        with open ("./data_pickles/validY.pickle",'wb') as f:
            pickle.dump(Y_valid,f)
    else:# process and load testing data
        X_test = Variable(torch.from_numpy(X_data).float())
        Y_test = Variable(torch.from_numpy(Y_data).float())
        with open ("./data_pickles/cnn_testX.pickle",'wb') as f:
            pickle.dump(X_test,f)
        with open ("./data_pickles/cnn_testY.pickle",'wb') as f:
            pickle.dump(Y_test,f)
    print ("loading finished..pickles saved to %s" % "./data_pickles/")
    
def loadPickles(flag):
     if flag == "train":
         with open ("./data_pickles/trainX.pickle",'rb') as f:
             X_train = pickle.load(f)
         with open ("./data_pickles/trainY.pickle",'rb') as f:
             Y_train = pickle.load(f)
         with open ("./data_pickles/validX.pickle",'rb') as f:
             X_valid = pickle.load(f)
         with open ("./data_pickles/validY.pickle",'rb') as f:
             Y_valid = pickle.load(f)
         return X_train,Y_train,X_valid,Y_valid
     else:
         with open ("./data_pickles/testX.pickle",'rb') as f:
             X_test = pickle.load(f)
         with open ("./data_pickles/testY.pickle",'rb') as f:
             Y_test = pickle.load(f)
         return X_test, Y_test

# classification success rate
def success_rate(pred_Y,Y):
     _,pred_Y_index = torch.max(pred_Y, 1)
     _,Y_index = torch.max(Y,1)
     num_equal = torch.sum(pred_Y_index.data == Y_index.data)
     num_different = torch.sum(pred_Y_index.data != Y_index.data)
     rate = num_equal / float(num_equal + num_different)
     return rate
    
class Net(nn.Module):
    def __init__(self,input_size, hidden_size, output_size):
        super(Net, self).__init__()
        # parameters as defined above
        self.fc1 = nn.Linear( input_size, hidden_size, bias=True)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear( hidden_size, output_size, bias=True)

    def forward(self, x):
        # activation function: relu
        out = self.fc1(x)
        out = self.relu(out)
        out = F.dropout(out, training = self.training) # use dropout regularization
        # use a softmax in accordance to class entropy objective function in the output layer
        out = F.log_softmax(self.fc2(out)) 
        return out

def convert_to_categories(Y):
    _, categories = torch.max(Y.data, 1)
    categories = torch.Tensor.long(categories)
    return Variable(categories)

def plot_confusion_matrix(mat, classes):
    plt.imshow(mat, interpolation = 'nearest')
    plt.title("Confusion Matrix")
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    thresh = mat.max()/2
    for i, j in itertools.product(range(mat.shape[0]), range(mat.shape[1])):
        plt.text(j, i, format(mat[i, j], 'd'),
                 horizontalalignment="center",
                 color="white" if mat[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    
if __name__ == "__main__":
    # training the network
    n_train = 3200
    epochs = 200
    batch_size = 32
    n_batches = int(np.ceil(n_train / batch_size))
    learning_rate = 1e-5

    dataDir = sys.argv[1]
    #loadData(dataDir,loadTrain= False)
    
    X_train,Y_train,X_valid,Y_valid = loadPickles("train")
    Y_train_cat = convert_to_categories(Y_train)
    Y_valid_cat = convert_to_categories(Y_valid)
    X_test,Y_test = loadPickles("test")
    Y_test_cat = convert_to_categories(Y_test)
    
    #  Create an instance of this network.
    net = Net(input_size, hidden_size, output_size)
    print (net.parameters())
    #net.cuda() # move stuff to GPU

    criterion = nn.NLLLoss()
    optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)
    
    pred_Y_valid = net(X_valid)

    valid_loss=criterion(pred_Y_valid,Y_valid_cat)
    print("Initial loss: %.5f" %valid_loss.data[0])
    losses = []
    train_success_rate = []
    validation_success_rate = []
    for ep in range(epochs):
        #  Create a random permutation of the indices of the row vectors.
        indices = torch.randperm(n_train)
    
        #  Run through each batch
        for b in range(n_batches):
            #  Use slicing (of the pytorch Variable) to extract the
            #  indices and then the data instances for the next mini-batch
            batch_indices = indices[b*batch_size:(b+1)*batch_size]
            batch_X = X_train[batch_indices]
            batch_Y = Y_train_cat[batch_indices]
        
            #  Run the network on each data instance in the minibatch
            #  and then compute the object function value
            optimizer.zero_grad()
            pred_Y = net(batch_X)
            loss = criterion(pred_Y, batch_Y)
            loss.backward()
            optimizer.step()

        pred_Y_train = net(X_train)
        pred_Y_valid = net(X_valid)
        valid_loss = criterion(pred_Y_valid, Y_valid_cat)
        r1 = success_rate(pred_Y_train, Y_train)
        r2 = success_rate(pred_Y_valid,Y_valid)
        train_success_rate.append(r1)
        validation_success_rate.append(r2)
        
        losses.append(valid_loss.data[0])
        #  Print validation loss every 10 epochs
        if ep != 0 and ep%10==0:
            #pred_Y_valid = net(X_valid)
            #valid_loss = criterion(pred_Y_valid, Y_valid_cat)
            print("Epoch %d loss: %.5f" %(ep, valid_loss.data[0]))
    #  Compute and print the final training and test loss
    #  function values
    net.eval()# turn off dropout in testing
    pred_Y_train = net(X_train)
    loss = criterion(pred_Y_train, Y_train_cat)
    print('Final training loss is %.5f' %loss.data[0])
    print ('Training success rate:',success_rate(pred_Y_train, Y_train))
    print ('Saving network model')
    torch.save(net.state_dict(), 'FC1.pkl')
    pred_Y_test = net(X_test)
    print('Test success rate:', success_rate(pred_Y_test, Y_test))
    
    # diagnostic
    x_axis = [x for x in range(epochs)]
    plt.figure(1)
    plt.title('losses vs epoch')
    plt.plot(x_axis, losses)
    plt.savefig('loss graph.png')
    plt.figure(2)
    plt.title('training/validation accuracy vs epoch')
    plt.plot(x_axis, train_success_rate,'r',)
    plt.plot(x_axis, validation_success_rate,'g')
    plt.savefig('classification accuracy.png')
    pred_Y_cat = convert_to_categories(pred_Y_train)
    mat = confusion_matrix(Y_train_cat.data.numpy(), pred_Y_cat.data.numpy())
    print ('plotting confusion matrix')
    plt.figure(3)
    plot_confusion_matrix(mat,['grass','ocean','redcarpet','road','wheatfield'])
    plt.savefig('training_confusion_matrix.png')
    plt.figure(4)
    pred_Y_test_cat = convert_to_categories(pred_Y_test)
    mat = confusion_matrix(Y_test_cat.data.numpy(),pred_Y_test_cat.data.numpy())
    plot_confusion_matrix(mat,['grass','ocean','redcarpet','road','wheatfield'] )
    plt.savefig('testing_confusion_matrix.png')
    plt.figure(5)
    pred_Y_valid_cat = convert_to_categories(pred_Y_valid)
    mat = confusion_matrix(Y_valid_cat.data.numpy(),pred_Y_valid_cat.data.numpy())
    plot_confusion_matrix(mat, ['grass','ocean','redcarpet','road','wheatfield'])
    plt.savefig('validation_confusion_matrix.png')

