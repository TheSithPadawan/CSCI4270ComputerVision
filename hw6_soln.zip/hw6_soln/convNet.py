import sys
import os
import cv2
import numpy as np
import torch
from torch.autograd import Variable
from sklearn.model_selection import train_test_split # cross validation
import torch.nn as nn
import torch.nn.functional as F
import pickle
from matplotlib import pyplot as plt
from torchvision import datasets, models, transforms
import torchvision
import torch.optim as optim

# need to fix the resize
def loadData(Dir,loadTrain = True):
    cats = ['grass','ocean','redcarpet','road','wheatfield']
    Xs = []
    Ys = []
    for i in range(len(cats)):
        path = os.path.join(Dir, cats[i])
        for f in os.listdir(path):
            Image = cv2.imread(os.path.join(path,f))
            Resized_Im = cv2.resize(Image, (256,256),interpolation = cv2.INTER_CUBIC)
            #X = Resized_Im.flatten()
            Y = np.zeros(5)
            Y[i] = 1
            Xs.append(Resized_Im)
            Ys.append(Y)
    X_data = np.vstack((Xs))
    Y_data = np.vstack((Ys))
    print (X_data.shape)
    print (Y_data.shape)
    return
    if loadTrain == True: # process and load training data
        X_train,X_valid,Y_train,Y_valid = train_test_split(X_data,Y_data,test_size = 0.2)
        X_train.transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        # convert to tensor
        X_train = Variable(torch.from_numpy(X_train).float())
        Y_train = Variable(torch.from_numpy(Y_train).float())
        X_valid,Y_valid = Variable(torch.from_numpy(X_valid).float()),Variable(torch.from_numpy(Y_valid).float())
        with open ("./data_pickles/trainX.pickle",'wb') as f:
            pickle.dump(X_train,f)
        with open ("./data_pickles/trainY.pickle",'wb') as f:
            pickle.dump(Y_train,f)
        with open ("./data_pickles/validX.pickle",'wb') as f:
            pickle.dump(X_valid, f)
        with open ("./data_pickles/validY.pickle",'wb') as f:
            pickle.dump(Y_valid,f)
    else:# process and load testing data
        X_test = Variable(torch.from_numpy(X_data).float())
        Y_test = Variable(torch.from_numpy(Y_data).float())
        with open ("./data_pickles/testX.pickle",'wb') as f:
            pickle.dump(X_test,f)
        with open ("./data_pickles/testY.pickle",'wb') as f:
            pickle.dump(Y_test,f)
    print ("loading finished..pickles saved to %s" % "./data_pickles/")
    
def loadPickles(flag):
     if flag == "train":
         with open ("./data_pickles/trainX.pickle",'rb') as f:
             X_train = pickle.load(f)
         with open ("./data_pickles/trainY.pickle",'rb') as f:
             Y_train = pickle.load(f)
         with open ("./data_pickles/validX.pickle",'rb') as f:
             X_valid = pickle.load(f)
         with open ("./data_pickles/validY.pickle",'rb') as f:
             Y_valid = pickle.load(f)
         return X_train,Y_train,X_valid,Y_valid
     else:
         with open ("./data_pickles/testX.pickle",'rb') as f:
             X_test = pickle.load(f)
         with open ("./data_pickles/testY.pickle",'rb') as f:
             Y_test = pickle.load(f)
         return X_test, Y_test

# classification success rate
def success_rate(pred_Y,Y):
     _,pred_Y_index = torch.max(pred_Y, 1)
     _,Y_index = torch.max(Y,1)
     num_equal = torch.sum(pred_Y_index.data == Y_index.data)
     num_different = torch.sum(pred_Y_index.data != Y_index.data)
     rate = num_equal / float(num_equal + num_different)
     return rate

def convert_to_categories(Y):
    _, categories = torch.max(Y.data, 1)
    categories = torch.Tensor.long(categories)
    return Variable(categories)


# load data
#loadData(sys.argv[1])
data_transforms = {
    'train': transforms.Compose([
        #transforms.RandomSizedCrop(224),
        #transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'test': transforms.Compose([
        #transforms.Scale(256),
        #transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
}
data_dir = '../hw5/hw5-data/'
image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x),
                                          data_transforms[x])
                  for x in ['train', 'test']}
dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=32,
                                             shuffle=True, num_workers=4)
              for x in ['train', 'test']}
dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'test']}
class_names = image_datasets['train'].classes

def imshow(inp, title=None):
    """Imshow for Tensor."""
    inp = inp.numpy().transpose((1, 2, 0))
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    inp = std * inp + mean
    inp = np.clip(inp, 0, 1)
    plt.imshow(inp)
    if title is not None:
        plt.title(title)
    plt.pause(0.001)  # pause a bit so that plots are updated


# Get a batch of training data
inputs, classes = next(iter(dataloaders['train']))

# Make a grid from batch
#out = torchvision.utils.make_grid(inputs)

#imshow(out, title=[class_names[x] for x in classes])
#plt.savefig('testimg.png')

# construct
model_ft = models.resnet18(pretrained=True)
num_ftrs = model_ft.fc.in_features
# output classes = 5
model_ft.fc = nn.Linear(num_ftrs, out_features = 5)
criterion = nn.CrossEntropyLoss()

# train
n_train = 3200
epochs = 10
batch_size = 32
n_batches = int(np.ceil(n_train / batch_size))
learning_rate = 1e-4

optimizer_ft = optim.SGD(model_ft.parameters(), lr=learning_rate, momentum=0.9)

for ep in range(epochs):
     running_loss = 0
     indices = torch.randperm(n_train)
     print('Epoch {}/{}'.format(ep, epochs - 1))
     print('-' * 10)
     for data in dataloaders["train"]:
         inputs,labels = data
         inputs,labels = Variable(inputs),Variable(labels)
         optimizer_ft.zero_grad()
         pred_Y = model_ft(inputs)
         # forward
         loss= criterion(pred_Y, labels)
         loss.backward()
         optimizer_ft.step()
         running_loss += loss.data[0]
      #validation stats for current ep
     #pred_Y_valid =  model_ft(X_valid)
     #valid_loss = criterion(pred_Y_valid,Y_valid_cat)
     print('Loss: {:.4f}'.format(running_loss/dataset_sizes["train"]))

# test
for data in dataloaders["test"]:
     inputs,labels = data
     inputs,labels = Variable(inputs),Variable(labels)
     outputs = model_ft(inputs)
     _, preds = torch.max(outputs.data, 1)
     corrects += torch.sum(preds == labels.data)
print ("testing accuracy: %.4f" % (corrects/dataset_sizes["test"]))
